function closepopupdiv()
{
	$("#popupdiv").hide();
}
/************************home loans********************************************/
function viewhomeloan(home_id)
{
	$("#popupdiv").show();
	$.post('jqajax/viewhomeloan.php',{home_id:home_id},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});	
}
function deletehomeloan(home_id)
{
	$("#popupdiv").show();
	$.post('jqajax/deletehomeloan.php',{home_id:home_id},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});	
}
/*************************************mortage loans****************************/
function viewmmortageloan(ml_id){
    $("#popupdiv").show();
	$.post('jqajax/viewmmortageloan.php',{ml_id:ml_id},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});
}
function deletemortageloan(ml_id)
{
	$("#popupdiv").show();
	$.post('jqajax/deletemortageloan.php',{ml_id:ml_id},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});	
}
/*******************************balance transfer*********************************/
function viewbalancetransfer(bt_id)
{
	$("#popupdiv").show();
	$.post('jqajax/viewbalancetransfer.php',{bt_id:bt_id},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});	
}
function deletebalancetranfer(bt_id)
{
	$("#popupdiv").show();
	$.post('jqajax/deletebalancetranfer.php',{bt_id:bt_id},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});	
}
/******************************personal loans*************************************/
function viewpersonalloan(pl_id)
{
	$("#popupdiv").show();
	$.post('jqajax/viewpersonalloan.php',{pl_id:pl_id},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});	
}
function deletepersonalloans(pl_id)
{
	$("#popupdiv").show();
	$.post('jqajax/deletepersonalloans.php',{pl_id:pl_id},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});	
}
/******************************business loans*************************************/
function viewbusinessloan(bl_id)
{
	$("#popupdiv").show();
	$.post('jqajax/viewbusinessloan.php',{bl_id:bl_id},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});	
}
function deletebusinessloans(bl_id)
{
	$("#popupdiv").show();
	$.post('jqajax/deletebusinessloans.php',{bl_id:bl_id},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});	
}
/*************************loan sms********************************/
function getloansms(loan_id,mobile){
    $("#popupdiv").show();
	$.post('jqajax/getloansms.php',{loan_id:loan_id,mobile:mobile},
	function(markup){
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});
}
/*********************************mail**********************************/
function getloanmail(){
    var email = $('#email').val();
    $("#popupdiv").show();
	$.post('jqajax/getloanmail.php',{email:email},
	function(markup){
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});
}
/**************************************************staff*********************************/
function getaddnewstaff(){
   $("#popupdiv").show();
	$.post('jqajax/getaddnewstaff.php',
	function(markup){
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	}); 
}
function deletestaff(sd_id){
    $("#popupdiv").show();
	$.post('jqajax/deletestaff.php',{sd_id:sd_id},
	function(markup){
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	}); 
}
/****************************assingn staff************************************************/
function getasssignstaff(){
    $("#popupdiv").show();
	$.post('jqajax/getasssignstaff.php',
	function(markup){
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	}); 
}
function getloandetail(str){
    if(str==""){
        alert('Please select assign for option');
    }if(str=="Home Loan"){
        $.post('jqajax/getasssignstaff.php',
        function(markup){
            $('#popup-main-content').html("");
            $('#popup-main-content').html(markup);
        });
    }if(str=="Balance Transfer"){
        
    }if(str=="Mortgage Loan"){
        
    }if(str=="Personal Loan"){
        
    }if(str=="Business Loan"){
        
    }
}
/***************************Search Product Name********************************/
function searchProductName(searchStr) 
{   
	if(searchStr=="")
	{
		document.getElementById("searchProductName").innerHTML="";
	}
	else
	{
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() 
		{
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
			{
				document.getElementById("searchProductName").innerHTML = xmlhttp.responseText;
			}
		};
		xmlhttp.open("GET", "searchProductName.php?searchStr=" + searchStr, true);
		xmlhttp.send();
	}
}   
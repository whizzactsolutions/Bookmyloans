<?php
ob_start();
require_once('../../includes/init.php');

$email= $_POST['admin_email'];

$pass = $_POST['admin_password'];


$ld=AdminDetail::authenticate($email,$pass);
if($ld)
{
	session_start();
	$_SESSION['admin_name']=$ld->name;
	$_SESSION['admin_email']=$ld->email;
	if($ld->active_status == "a")
	{
		redirect_to("../secure/index.php");
	}
}
else
{
	redirect_to("../index.php");
}
?>

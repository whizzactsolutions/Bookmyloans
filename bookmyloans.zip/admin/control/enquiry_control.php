<?php
ob_start();
session_start();
require_once('../../includes/init.php');
$mode=$_GET['mode'];
if(isset($mode))
{
	if($mode=='i')
	{
		$qnuiry=new EnquiryDetail();
		$qnuirync=EnquiryDetail::find_next_code();
		if($qnuirync)
		{
			foreach($qnuirync as $nextcode)
			{
				$qnuiry->enquiry_code=$qnuirync->enquiry_code+1;
			}
		}
		else
		{
			$qnuiry->enquiry_code=1;
		}
		
		$qnuiry->name = $_POST['name'];
		$qnuiry->email = $_POST['email'];
		$qnuiry->mobile = $_POST['mobile'];
		$qnuiry->comment = $_POST['comment'];
		$qnuiry->enquiry_date = date('d/m/Y');
		
		$qnuiry->save();
		
		redirect_to("../../contact_us.php");
	}

	if($mode=='d')
	{
		$qnuiry=new EnquiryDetail();
		
		$qnuiry->enquiry_code=$_POST['enquiry_code'];
		if($qnuiry->delete())
		{
			redirect_to("../secure/enquiry.php");
		}
	}

	if($mode=='u')
	{
		$qnuiry=new EnquiryDetail();
			
		$qnuiry->enquiry_code = $_POST['enquiry_code'];
		$qnuiry->category_code = $_POST['category_code'];
		$qnuiry->product_Name1 = $_POST['product_Name1'];
		$qnuiry->product_Name2 = $_POST['product_Name2'];
		$qnuiry->product_Name3 = $_POST['product_Name3'];
		$qnuiry->product_img = $_POST['product_img'];
		$qnuiry->product_desc = $_POST['product_desc'];
		$qnuiry->model_no = $_POST['model_no'];
		$qnuiry->standards = $_POST['standards'];
		$qnuiry->pdf_path = $_POST['pdf_path'];
		$qnuiry->manufacture = $_POST['manufacture'];
		$qnuiry->active_status = $_POST['active_status'];
		$qnuiry->update();
		redirect_to("../secure/viewcategory.php");	
	}
	redirect_to("../../index.php");
}
?>
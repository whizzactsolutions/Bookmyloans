<?php
    $email = $_POST['email'];
    $$body = $_POST['message'];
    
    /**************************mail**************************/
    $to = $email;
    $subject = 'Bookmyloans Confirmation mail';
    $message = '
    <html>
    <head>
    <title>Bookmyloans Confirmation mail</title>
    </head>
    <body>
        '.$body.'
    </body>
    </html>
    ';

    // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    // More headers
    $headers .= 'From: <enquiry@bookmyloans.co.in>' . "\r\n";
    $headers .= 'Cc: salunke.rajesh@gmail.com' . "\r\n";
    if(mail($to,$subject,$message,$headers)){
        header('Location: ../secure/index.php');
    }else{
        header('Location: ../secure/index.php');
    }
    /************************end mail************************/
?>

<?php
ob_start();
session_start();
require_once('../../includes/init.php');
$mode=$_GET['mode'];
if(isset($mode))
{
	if($mode=='i')
	{
		$staff=new StaffDetail();
		$staffnc=StaffDetail::find_next_code();
		if($staffnc)
		{
            $staff->sd_id=$staffnc->sd_id+1;
		}
		else
		{
			$staff->sd_id=1;
		}
		

		$staff->name = $_POST['sname'];
		$staff->email_id = $_POST['semail'];
		$staff->password = $_POST['spassword'];
		$staff->mobile = $_POST['smobile'];
		$staff->address = nl2br($_POST['saddress']);
		$staff->role_id = '2';
		$staff->password = $_POST['spassword'];
		
		$staff->active_status="a";
		$staff->created_at=date('d-m-Y');
		
		$staff->save();
		
		redirect_to("../secure/staffdetail.php");
	}

	if($mode=='d')
	{
		$staff=new StaffDetail();
		
		$staff->sd_id=$_POST['sd_id'];
		if($staff->delete())
		{
			redirect_to("../secure/staffdetail.php");
		}
	}

	if($mode=='u')
	{
		$staff=new StaffDetail();
			
		$cate=StaffDetail::find_by_code($_POST['sd_id']);
		if($cate)
		{
		}

		$staff->sd_id = $_POST['sd_id'];
		$staff->mainsd_id = $_POST['mainsd_id'];
		$staff->category_name = $_POST['category_name'];
		$staff->category_desc = nl2br($_POST['category_desc']);
		/**********************************/
		if(isset($_FILES['category_img']))
		{
			$errors= array();
			$file_name = $_FILES['category_img']['name'];
			$file_size =$_FILES['category_img']['size'];
			$file_tmp =$_FILES['category_img']['tmp_name'];
			$file_type=$_FILES['category_img']['type'];
			
			$tmp = explode('.', $file_name);
			$file_ext = end($tmp);
			//$file_ext=strtolower(end(explode('.',$file_name)));

			$expensions= array('jpg', 'jpeg', 'gif', 'png');
			$max_file_size = 10 * 1024 * 1024; #10Mb
			if(in_array($file_ext,$expensions)=== false){
			 $errors[]="extension not allowed, please choose a valid file.";
			}

			if($file_size > $max_file_size){
			 $errors[]='File size must be excately 10 MB';
			}

			if(empty($errors)==true){
				$name=uniqid().'.'.$file_ext;
				$upload_img='category_img/'.$name;
				move_uploaded_file($file_tmp,'../'.$upload_img);
			 //$upload_dest_file='../../images/slider/';

			}else{
			 print_r($errors);
			}
			$staff->category_img = $upload_img;
		}
		else
		{
			$staff->category_img = $cate->category_img;
		}
		/**********************************/
		$staff->active_status = $_POST['active_status'];
		$staff->update();
		redirect_to("../secure/viewcategory.php");	
	}
	redirect_to("../../index.php");
}
?>
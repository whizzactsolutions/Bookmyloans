<?php 
session_start();
if(!isset($_SESSION['admin_name']))
{
	header('Location: ../index.php');
}	
require_once('../../includes/init.php');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include('topheader.php'); ?>
   </head>
<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <?php include('topnavigation.php'); ?>
		<!-- end navbar top -->
        <!-- navbar side -->
       <?php include('sidenavigation.php'); ?>
		<!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Dashboard</h1>
                </div>
                <!--End Page Header -->
            </div>
            <div class="row">
                <!-- Welcome -->
                <div class="col-lg-12">
                    <div class="alert alert-info">
                        <i class="fa fa-folder-open"></i><b>&nbsp;Hello ! </b>Welcome Back <b><?php echo $_SESSION['admin_name']; ?> </b>
 
                    </div>
                </div>
                <!--end  Welcome -->
            </div>
				<?php include("mainmenupanel.php");?>
            </div>
		 </div>
        <!-- end page-wrapper -->
    <!-- end wrapper -->
    <?php include('footer.php'); ?>
</body>
</html>

<?php
$pl_id=$_POST['pl_id'];
//echo $category_id;
require_once('../../../includes/init.php');

$cate=PersonalLoan::find_by_code($pl_id);
if($cate)
{	
	echo '<h2 style="color:#800000;">ARE YOU SURE TO DELETE <strong>'.$cate->full_name.'</strong></h2><br>';
}	

?>
<form method="post" action="../../control/personal_control.php?mode=d">
	<input type="submit" VALUE="YES" class="btn btn-primary">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="NO" class="btn btn-danger" onclick="closepopupdiv()">
<input type="hidden" name="pl_id" value="<?php echo $pl_id; ?>">
</form>
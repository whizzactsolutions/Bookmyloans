<?php
$sd_id=$_POST['sd_id'];
//echo $category_id;
require_once('../../../includes/init.php');

$cate=StaffDetail::find_by_id($sd_id);
if($cate)
{	
	echo '<h2 style="color:#800000;">ARE YOU SURE TO DELETE <strong>'.$cate->name.'</strong></h2><br>';
}	

?>
<form method="post" action="../control/staff_control.php?mode=d">
	<input type="submit" VALUE="YES" class="btn btn-primary">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="NO" class="btn btn-danger" onclick="closepopupdiv()">
<input type="hidden" name="sd_id" value="<?php echo $sd_id; ?>">
</form>
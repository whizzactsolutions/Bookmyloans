<form action="../control/staff_control.php?mode=i" method="post">
<table class="table table-bordered" style="width:60%;">
<tr>
    <td>Name</td>
    <td><input type="text" name="sname" class="form-control" required></td>
</tr>
<tr>
    <td>Email</td>
    <td><input type="email" name="semail" class="form-control" required></td>
</tr>
<tr>
    <td>Mobile No</td>
    <td><input type="tel" name="smobile" class="form-control" maxlength="10" minlength="10" required></td>
</tr>
<tr>
    <td>Address</td>
    <td><textarea name="saddress" class="form-control"></textarea></td>
</tr>
<tr>
    <td>Password</td>
    <td><input type="password" name="spassword" class="form-control" required></td>
</tr>
<tr>
    <td colspan="2"><input type="submit" value="Save" class="btn btn-primary" style="float:right;"></td>
</tr>
</table>
</form>
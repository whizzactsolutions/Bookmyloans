<h2>Role assing for staff</h2>
<table class="table table-bordered" style="width:60%;">
    <tr>
        <td> Staff Name </td>
        <td>
            <select class="form-control" name="sd_id" id="sd_id">
            <option value=""> Select staff name</option>
                <?php
                require_once('../../../includes/init.php');
                $staff = StaffDetail::find_all();
                if($staff){
                    foreach($staff as $allstaff){
                        echo '<option value="'.$allstaff->sd_id.'">'.$allstaff->name.'</option>';
                    }
                } 
                ?>
            </select>
        </td>
    </tr>
    <tr>
        <td>Assign for</td>
        <td>
            <select class="form-control" id="loan" name="loan" onchange="getloandetail(this.value)">
                <option value="">select Loan</option>
                <option value="Home Loan">Home Loan</option>
                <option value="Balance Transfer">Balnce Tranfer</option>
                <option value="Mortgage Loan">Mortgages Loan</option>
                <option value="Personal Loan">Personal Loan</option>
                <option value="Business Loan">Business Loan </option>
            </select>
        </td>
    </tr>
    <tr>
       <td>Client Name</td>
        <td></td>
    </tr>
</table>
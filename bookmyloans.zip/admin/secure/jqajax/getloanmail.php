<?php
$email = $_POST['email'];
?>

<form action="../control/sendemail_control.php" method="post">
    <center>
<strong>Message:</strong> <textarea class="form-control" placeholder="" name="message" style="width:50%;"></textarea><br>
    <input type="submit" value="Send" class="btn btn-primary">
    <input type="hidden" name="email" value="<?php echo $email;?>">
        </center>
</form>
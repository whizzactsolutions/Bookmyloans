<?php
$loan_id = $_POST['loan_id'];
$mobile = $_POST['mobile'];
?>

<form action="../control/sendsms_control.php" method="post">
    <center>
<strong>Message:</strong> <textarea class="form-control" name="subject" placeholder="" name="message" style="width:50%;"></textarea><br>
    <input type="submit" value="Send" class="btn btn-primary">
    <input type="hidden" name="loan_id" value="<?php echo $loan_id;?>">
    <input type="hidden" name="mobile" value="<?php echo $mobile;?>">
        </center>
</form>
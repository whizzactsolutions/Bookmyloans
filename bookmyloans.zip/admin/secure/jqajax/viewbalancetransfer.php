<?php
require_once('../../../includes/init.php');
$bt_id=$_POST['bt_id'];
$x=0;
$allcate=BalanceTranfer::find_by_code($bt_id);
if($allcate)
{
}	
?>
<h3 class="alert alert-info">View Balance Transfer Detail of <?php echo $allcate->full_name;?></h3>

<table class="table table-bordered" style="width:70%;">
<tr>
	<td>Name</td>
	<td><?php echo $allcate->full_name;?></td>
</tr>
<tr>
	<td>Email</td>
	<td><?php echo $allcate->email_id;?></td>
</tr>
<tr>
	<td>Mobile</td>
	<td><?php echo $allcate->mobile;?></td>
</tr>
<tr>
	<td>Date of Birth</td>
	<td><?php echo $allcate->dob;?></td>
</tr>
<tr>
	<td>Gender</td>
	<td><?php echo $allcate->gender;?></td>
</tr>
<tr>
	<td>Purpose</td>
	<td><?php echo $allcate->purpose;?></td>
</tr>
<tr>
	<td>Occupation</td>
	<td><?php echo $allcate->occupation;?></td>
</tr>
<tr>
	<td>Residency Location</td>
	<td><?php echo $allcate->residency_location;?></td>
</tr>
<tr>
	<td>Loan Amount</td>
	<td><?php echo $allcate->loan_amount;?></td>
</tr>
<tr>
	<td>Monthly Income</td>
	<td><?php echo $allcate->monthly_income;?></td>
</tr>
<tr>
	<td>Co-applicant</td>
	<td><?php echo $allcate->co_applicant;?></td>
</tr>
<tr>
	<td>Property Value</td>
	<td><?php echo $allcate->property_value;?></td>
</tr>
<tr>
	<td>Property Name</td>
	<td><?php echo $allcate->property_name;?></td>
</tr>
<tr>
	<td>Company Name</td>
	<td><?php echo $allcate->copany_name;?></td>
</tr>
<tr>
	<td>Salary Received</td>
	<td><?php echo $allcate->salary_received;?></td>
</tr>
<tr>
	<td>Since Bussiness</td>
	<td><?php echo $allcate->since_bussiness;?></td>
</tr>
<tr>
	<td>IT Return</td>
	<td><?php echo $allcate->it_return;?></td>
</tr>
<tr>
	<td>Turn Over</td>
	<td><?php echo $allcate->turnover;?></td>
</tr>
<tr>
	<td>Existing Bank</td>
	<td><?php echo $allcate->existingbank;?></td>
</tr>
<tr>
	<td>Apply Date</td>
	<td><?php echo $allcate->created_at;?></td>
</tr>
</table>
<?php
require_once('../../../includes/init.php');
$home_id=$_POST['home_id'];
$x=0;
$allcate=HomeLoan::find_by_code($home_id);
if($allcate)
{
}	
?>
<h3 class="alert alert-info">View Home Loan Detail of <?php echo $allcate->full_name;?></h3>

<table class="table table-bordered" style="width:70%;">
<tr>
	<td>Name</td>
	<td><?php echo $allcate->full_name;?></td>
</tr>
<tr>
	<td>Email</td>
	<td><?php echo $allcate->email_id;?></td>
</tr>
<tr>
	<td>Mobile</td>
	<td><?php echo $allcate->mobile;?></td>
</tr>
<tr>
	<td>Date of Birth</td>
	<td><?php echo $allcate->dob;?></td>
</tr>
<tr>
	<td>Gender</td>
	<td><?php echo $allcate->gender;?></td>
</tr>
<tr>
	<td>Purpose</td>
	<td><?php echo $allcate->purpose;?></td>
</tr>
<tr>
	<td>Occupation</td>
	<td><?php echo $allcate->occupation;?></td>
</tr>
<tr>
	<td>Residency Location</td>
	<td><?php echo $allcate->residency_location;?></td>
</tr>
<tr>
	<td>Loan Amount</td>
	<td><?php echo $allcate->loan_amount;?></td>
</tr>
<tr>
	<td>Monthly Income</td>
	<td><?php echo $allcate->monthly_income;?></td>
</tr>
<tr>
	<td>Co-applicant</td>
	<td><?php echo $allcate->co_applicant;?></td>
</tr>
<tr>
	<td>Coapp-income</td>
	<td><?php echo $allcate->coapp_income;?></td>
</tr>
<tr>
	<td>Property Finalized</td>
	<td><?php echo $allcate->property_finalized;?></td>
</tr>
<tr>
    <td>Property Location</td>
	<td><?php echo $allcate->property_location;?></td>
</tr>
<tr>
	<td>Property Value</td>
	<td><?php echo $allcate->property_value;?></td>
</tr>
<tr>
	<td>Property Name</td>
	<td><?php echo $allcate->property_name;?></td>
</tr>
<tr>
	<td>Apply Date</td>
	<td><?php echo $allcate->created_at;?></td>
</tr>
</table>
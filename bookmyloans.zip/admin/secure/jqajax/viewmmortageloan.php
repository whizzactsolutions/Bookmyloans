<?php
require_once('../../../includes/init.php');
$ml_id=$_POST['ml_id'];
$x=0;
$allcate=MotrageLoan::find_by_code($ml_id);
if($allcate)
{
}	
?>
<h3 class="alert alert-info">View Mortagage Loan Detail of <?php echo $allcate->full_name;?></h3>

<table class="table table-bordered" style="width:70%;">
<tr>
	<td>Name</td>
	<td><?php echo $allcate->full_name;?></td>
</tr>
<tr>
	<td>Email</td>
	<td><?php echo $allcate->email_id;?></td>
</tr>
<tr>
	<td>Mobile</td>
	<td><?php echo $allcate->mobile;?></td>
</tr>
<tr>
	<td>Date of Birth</td>
	<td><?php echo $allcate->dob;?></td>
</tr>
<tr>
	<td>Gender</td>
	<td><?php echo $allcate->gender;?></td>
</tr>
<tr>
	<td>Residency Location</td>
	<td><?php echo $allcate->residency_location;?></td>
</tr>
<tr>
	<td>Loan Amount</td>
	<td><?php echo $allcate->loan_amount;?></td>
</tr>
<tr>
	<td>Monthly Income</td>
	<td><?php echo $allcate->monthly_income;?></td>
</tr>
<tr>
	<td>Property Value</td>
	<td><?php echo $allcate->property_value;?></td>
</tr>
<tr>
	<td>Apply Date</td>
	<td><?php echo $allcate->created_at;?></td>
</tr>
</table>
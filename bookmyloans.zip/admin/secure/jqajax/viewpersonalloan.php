<?php
require_once('../../../includes/init.php');
$pl_id=$_POST['pl_id'];
$x=0;
$allcate=PersonalLoan::find_by_code($pl_id);
if($allcate)
{
}	
?>
<h3 class="alert alert-info">View Personal Loan Detail of <?php echo $allcate->full_name;?></h3>

<table class="table table-bordered" style="width:70%;">
<tr>
	<td>Name</td>
	<td><?php echo $allcate->full_name;?></td>
</tr>
<tr>
	<td>Email</td>
	<td><?php echo $allcate->email_id;?></td>
</tr>
<tr>
	<td>Mobile</td>
	<td><?php echo $allcate->mobile;?></td>
</tr>
<tr>
	<td>Date of Birth</td>
	<td><?php echo $allcate->dob;?></td>
</tr>
<tr>
	<td>Gender</td>
	<td><?php echo $allcate->gender;?></td>
</tr>
<tr>
	<td>Occupation</td>
	<td><?php echo $allcate->occupation;?></td>
</tr>
<tr>
	<td>Residency Location</td>
	<td><?php echo $allcate->residency_location;?></td>
</tr>
<tr>
	<td>Loan Amount</td>
	<td><?php echo $allcate->loan_amount;?></td>
</tr>
<tr>
	<td>Monthly Income</td>
	<td><?php echo $allcate->monthly_income;?></td>
</tr>
<tr>
	<td>Company Name</td>
	<td><?php echo $allcate->copany_name;?></td>
</tr>
<tr>
	<td>Salary Received</td>
	<td><?php echo $allcate->salary_received;?></td>
</tr>
<tr>
	<td>Since Bussiness</td>
	<td><?php echo $allcate->since_bussiness;?></td>
</tr>
<tr>
	<td>IT Return</td>
	<td><?php echo $allcate->it_return;?></td>
</tr>
<tr>
	<td>Turn Over</td>
	<td><?php echo $allcate->turnover;?></td>
</tr>
<tr>
	<td>Rasident type</td>
	<td><?php echo $allcate->resident_type;?></td>
</tr>
<tr>
	<td>Past Loan</td>
	<td><?php echo $allcate->past_loan;?></td>
</tr>
<tr>
	<td>EMI</td>
	<td><?php echo $allcate->emi;?></td>
</tr>
<tr>
	<td>Apply Date</td>
	<td><?php echo $allcate->created_at;?></td>
</tr>
</table>
 <div class="row">
                
          
				 <div class="col-lg-3">
                    <div class="alert alert-info text-center">
                        <a href="staffdetail.php"><img src="../assets/img/multy-user.png" style="width:70px;"><br>&nbsp;<strong>Staff Details</strong></a>

                    </div>
                </div>
                     <div class="col-lg-3">
                    <div class="alert alert-info text-center">
                        <a href="clientassing.php"><img src="../assets/img/2140-512.png" style="width:70px;"><br>&nbsp;<strong>Client Assing to Staff</strong></a>

                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="alert alert-danger text-center">
                        <a href="homeloans.php"><img src="../../images/payment-512.png" style="width:70px;"><br>&nbsp;<strong>Home Loan Enquiry</strong></a>

                    </div>
                </div>
				<div class="col-lg-3">
                    <div class="alert alert-danger text-center">
                        <a href="mortgagesloans.php"><img src="../../images/Mortgage-512.png" style="width:70px;"><br>&nbsp;<strong>Mortgages Loan Enquiry</strong></a>

                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="alert alert-success text-center">
                        <a href="balancetranfer.php"><img src="../../images/balance-transfers.png" style="width:70px;"><br><strong>Balance Transfer Enquiry</strong></a>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="alert alert-warning text-center">
                        <a href="balancetranfer.php"><img src="../../images/Personal%20loan%20image.png" style="width:70px;"><br><strong>Personal loan Enquiry</strong></a>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="alert alert-warning text-center">
                        <a href="businessloans.php"><img src="../../images/business-loan-icon-blue.png" style="width:70px;"><br><strong>Business loan Enquiry</strong></a>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="alert alert-warning text-center">
                        <a href="enuirydetail.php"><i class="fa fa-envelope-o fa-3x" style="font-size:70px;"></i><br><strong>Enquiry Details</strong></a>
                    </div>
                </div>
		
            </div>
<div class="row">
                <!--quick info section -->
                
                 <div class="col-lg-3">
                    <div class="alert alert-warning text-center">
                        <a href="enquiry.php"><i class="fa fa-envelope-o fa-3x"></i><br>Enquiry Details</a>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="alert alert-warning text-center">
                        <a href="view_quote.php"><i class="fa fa-quote-left fa-3x"></i><br>Quote Details</a>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="alert alert-info text-center">
                        <a href="#!"><i class="fa fa-video-camera fa-3x"></i><br>View Video Details</a>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="alert alert-info text-center">
                        <a href="#!"><i class="fa fa-picture-o fa-3x"></i><br>View Photo Details</a>
                    </div>
                </div>
                <!--end quick info section -->
            </div>
            
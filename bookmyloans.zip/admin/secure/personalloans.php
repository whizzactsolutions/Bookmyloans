<?php 
session_start();
if(!isset($_SESSION['admin_name']))
{
	header('Location: ../index.php');
}	
require_once('../../includes/init.php');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include('topheader.php'); ?>
	<style type="text/css">
		.table-fixed thead {
  width: 100%;
}
.table-fixed tbody {
  height: 600px;
  overflow-y: auto;
  width: 100%;
}
.table-fixed thead, .table-fixed tbody, .table-fixed tr, .table-fixed td, .table-fixed th {
  display: block;
}
.table-fixed tbody td, .table-fixed thead > tr> th {
  float: left;
  border-bottom-width: 0;
}
	</style>
   </head>
<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <?php include('topnavigation.php'); ?>
		<!-- end navbar top -->
        <!-- navbar side -->
       <?php include('sidenavigation.php'); ?>
		<!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h3 class="page-header"><strong>PERSONAL LOANS</strong></h3>
                </div>
                <!--End Page Header -->
            </div>
			
			<!-------TABLE-------->

<div class="row">
<div class="col-lg-12">
  <!--Simple table example -->
    <div class="panel panel-primary">
	<div class="panel-heading">
	    <i class="fa fa-bar-chart-o fa-fw"></i>PERSONAL LOANS
<!--
	    <div class="pull-right">
		<div class="btn-group">
		   
		<a href="addcategory.php"><input type="button" value="ADD NEW CATEGORY" onclick="" class="btn btn-success btn-sm"></a>
		    
		</div>
	    </div>
-->
	</div>

	<div class="panel-body">
	    <div class="row">
		<div class="col-lg-12">
		    <div class="table-responsive">
			<table class="table-bordered table-hover table-striped " style="width:100%;">
			    <thead>
				<tr class="alet alert-info">
				    <th>S.R.No.</th>
				    <th>NAME</th>
				    <th>MOBILE</th>
				    <th>EMAIL</th>
                    <th>OCCUPATION</th>
				    <th>LOAN AMOUNT</th>
				    <th>MONTHALY INCOME</th>
				    <th>APPLY DATE</th>
				    <th>VIEW</th>
				    <th>MAIL</th>
				    <th>SMS</th>
				    <th>DELETE</th>
				</tr>
			    </thead>
			    <tbody>
                    <?php 
                    $x=0;
                    $home = PersonalLoan::find_all();
                    if($home){
                        foreach($home as $allhome){
                            $x=$x+1;
                            echo '<tr>
                                    <td>'.$x.'</td>
                                    <td>'.$allhome->full_name.'</td>
                                    <td>'.$allhome->mobile.'</td>
                                    <td>'.$allhome->email_id.'</td>
                                    <td>'.$allhome->occupation.'</td>
                                    <td>'.$allhome->loan_amount.'</td>
                                    <td>'.$allhome->monthly_income.'</td>
                                    <td>'.$allhome->created_at.'</td>
                                    <td><button class="btn btn-sm btn-primary" onclick="viewpersonalloan('.$allhome->pl_id.')"><i class="fa fa-eye" aria-hidden="true"></i></button></td>
                                    <td><input type="hidden" id="email" value="'.$allhome->email_id.'"><button value="Mail" class="btn btn-sm" onclick="getloanmail()"><i class="fa fa-envelope" aria-hidden="true"></i></button></td>
                                    <td><button value="SMS" class="btn btn-sm btn-success" onclick="getloansms('.$allhome->pl_id.','.$allhome->mobile.')"><i class="fa fa-mobile-phone" aria-hidden="true"></i></button></td>
                                    <td><button value="Delete" class="btn btn-sm btn-danger" onclick="deletepersonalloans('.$allhome->pl_id.')"><i class="fa fa-trash" aria-hidden="true"></i></button></td>
                                </tr>';
                        }
                    }
                    
                    ?>				    
			    </tbody>
			</table>
		    </div>

		</div>

	    </div>
	    <!-- /.row -->
	</div>
	<!-- /.panel-body -->
    </div>
</div>
			<!------END TABLE----->
    </div>
	</div>
		 </div>
<div id="popupdiv" class="popupdiv">
    <div class="popupdiv-content">	
        <span class="close" onclick="closepopupdiv()">&times;</span>
        <br>
        <center>
            <div id="popup-main-content">


            </div><br>
            <button onclick="closepopupdiv()" class="btn">Close</button>
        </center>
    </div>
</div>
    <!-- end wrapper -->
    <?php include('footer.php'); ?>
</body>
</html>

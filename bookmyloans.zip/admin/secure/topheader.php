<title>Bookmyloans | Home</title>
<link rel="shortcut icon" type="image/x-icon" href="" />
<!-- Core CSS - Include with every page -->
<link href="../assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
<link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href="../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
<link href="../assets/css/style.css" rel="stylesheet" />
<link href="../assets/css/main-style.css" rel="stylesheet" />

<link href="../assets/css/itq.css" rel="stylesheet" />
 <script src="../assets/js/itq.js"></script>

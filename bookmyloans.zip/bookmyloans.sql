-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2018 at 05:07 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bookmyloans`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `passowrd` varchar(255) DEFAULT NULL,
  `last_login` varchar(255) DEFAULT NULL,
  `active_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `balancetransfer`
--

CREATE TABLE IF NOT EXISTS `balancetransfer` (
  `bt_id` int(11) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `residency_location` varchar(255) DEFAULT NULL,
  `loan_amount` varchar(255) DEFAULT NULL,
  `monthly_income` varchar(255) DEFAULT NULL,
  `co_applicant` varchar(255) DEFAULT NULL,
  `property_finalized` varchar(255) DEFAULT NULL,
  `property_location` varchar(255) DEFAULT NULL,
  `property_value` varchar(255) DEFAULT NULL,
  `property_name` varchar(255) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `active_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `balancetransfer`
--

INSERT INTO `balancetransfer` (`bt_id`, `full_name`, `email_id`, `mobile`, `dob`, `gender`, `purpose`, `occupation`, `residency_location`, `loan_amount`, `monthly_income`, `co_applicant`, `property_finalized`, `property_location`, `property_value`, `property_name`, `created_at`, `updated_at`, `active_status`) VALUES
(1, 'durgesh', 'durgesh@gmail.com', '8268108343', '2018-03-29', 'Male', 'Transfer Home Loan', 'Self Employed (Business)', 'Surat', '12121212', '54545454', 'Yes', 'Yes', 'Buy Ready to occupy Home', '545454545', 'fgfgfg', '2018-03-29', '2018-03-29', 'a'),
(2, 'bvbvb', 'vbvb@ggg.gg', '545454545454', '2018-03-29', 'Male', 'Transfer Home Loan', 'Salaried', 'Delhi', '45454545', '45454545', 'Yes', 'Yes', 'Buy Ready to occupy Home', '45454545', 'ghfghghg', '2018-03-29', '2018-03-29', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `business_loan`
--

CREATE TABLE IF NOT EXISTS `business_loan` (
  `bl_id` int(11) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `residency_location` varchar(255) DEFAULT NULL,
  `loan_amount` varchar(255) DEFAULT NULL,
  `monthly_income` varchar(255) DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `resident_type` varchar(255) DEFAULT NULL,
  `past_loan` varchar(255) DEFAULT NULL,
  `copany_name` varchar(255) DEFAULT NULL,
  `salary_received` varchar(255) DEFAULT NULL,
  `since_bussiness` varchar(255) DEFAULT NULL,
  `it_return` varchar(255) DEFAULT NULL,
  `turnover` varchar(255) DEFAULT NULL,
  `emi` varchar(255) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `active_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `business_loan`
--

INSERT INTO `business_loan` (`bl_id`, `full_name`, `email_id`, `mobile`, `dob`, `gender`, `residency_location`, `loan_amount`, `monthly_income`, `occupation`, `resident_type`, `past_loan`, `copany_name`, `salary_received`, `since_bussiness`, `it_return`, `turnover`, `emi`, `created_at`, `updated_at`, `active_status`) VALUES
(1, 'durgesh@gmail.com', 'durgesh@gmail.com', '8268108343', '2018-03-29', 'Male', 'Mumbai', '23232323232', '434343', 'Salaried', 'Self/Spouse Owned', 'Yes', '', '', '', '', '', '4343', '2018-03-29', '2018-03-29', 'a'),
(2, 'durgesh@gmail.com', 'durgesh@gmail.com', '8268108343', '2018-03-29', 'Male', 'Mumbai', '23232323232', '34343434', 'Salaried', 'Self/Spouse Owned', 'Yes', 'Whizzactsolutions', '3434343', '', '', '', '3434', '2018-03-29', '2018-03-29', 'a'),
(3, 'durgesh@gmail.com', 'durgesh@gmail.com', '8268108343', '2018-03-21', 'Male', 'Mumbai', '23232323232', '45454', 'Self Employed (Business)', 'Family Owned', 'Yes', '', '', '2 to 5 years', 'Less than 2 Years', '45454545', '54545', '2018-03-29', '2018-03-29', 'a'),
(4, 'durgesh@gmail.com', 'durgesh@gmail.com', '8268108343', '2018-03-29', 'Male', 'Mumbai', '23232323232', '34343434', 'Self Employed (Professional)', 'Family Owned', 'No', '', '', '5 to 10 years', '2 or more years', '43434343434434', '434343', '2018-03-29', '2018-03-29', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `homeloans`
--

CREATE TABLE IF NOT EXISTS `homeloans` (
  `home_id` int(11) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `residency_location` varchar(255) DEFAULT NULL,
  `loan_amount` varchar(255) DEFAULT NULL,
  `monthly_income` varchar(255) DEFAULT NULL,
  `co_applicant` varchar(255) DEFAULT NULL,
  `coapp_income` varchar(255) NOT NULL,
  `property_finalized` varchar(255) DEFAULT NULL,
  `property_location` varchar(255) DEFAULT NULL,
  `property_value` varchar(255) DEFAULT NULL,
  `property_name` varchar(255) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `active_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`home_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `homeloans`
--

INSERT INTO `homeloans` (`home_id`, `full_name`, `email_id`, `mobile`, `dob`, `gender`, `purpose`, `occupation`, `residency_location`, `loan_amount`, `monthly_income`, `co_applicant`, `coapp_income`, `property_finalized`, `property_location`, `property_value`, `property_name`, `created_at`, `updated_at`, `active_status`) VALUES
(1, 'df', 'gfg@hh', '34343434343', '2018-03-29', 'Male', 'Buy Ready to occupy Home', 'Salaried', 'Surat', '4343434343', '43434343', '', '343434343', 'Yes', 'Buy Under-Construction Home', '3434343', '4343434', '0000-00-00', '0000-00-00', 'a'),
(2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 'a'),
(3, 'Durgesh', 'durgesh@gmail.com', '8268108343', '2018-03-29', 'Male', 'Buy Ready to occupy Home', 'Salaried', 'Delhi', '1234232323', '3343434343', 'Yes', '3434343434', 'Yes', 'Buy Ready to occupy Home', '34343434343', 'dfdfdf', '2018-03-29', '2018-03-29', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `location_details`
--

CREATE TABLE IF NOT EXISTS `location_details` (
  `location_code` int(12) NOT NULL,
  `location_name` varchar(20) DEFAULT NULL,
  `zone_code` int(12) DEFAULT NULL,
  PRIMARY KEY (`location_code`),
  UNIQUE KEY `location_name` (`location_name`),
  KEY `zone_code` (`zone_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location_details`
--

INSERT INTO `location_details` (`location_code`, `location_name`, `zone_code`) VALUES
(1, 'CST', 1),
(2, 'masjid', 1),
(3, 'fort', 1),
(4, 'sandhurst road', 1),
(5, 'dockyard road', 1),
(6, 'reay road', 1),
(7, 'cotton green', 2),
(8, 'sewri', 2),
(9, 'wadala road', 2),
(10, 'gtb nagar', 2),
(11, 'antop hill', 2),
(12, 'chunabhatti', 2),
(13, 'king circle', 2),
(14, 'kurla', 3),
(15, 'tilak nagar', 3),
(16, 'chembur', 3),
(17, 'govandi', 3),
(18, 'suman nagar', 3),
(19, 'mankhurd', 3),
(20, 'vashi', 4),
(21, 'sanpada', 4),
(22, 'palm beach road', 4),
(23, 'jui nagar', 4),
(24, 'nerul', 4),
(25, 'sea wood', 4),
(26, 'belapur', 5),
(27, 'kharghar', 5),
(28, 'khandeshwar', 5),
(29, 'panvel', 5),
(30, 'new panvel', 5),
(31, 'passyani', 5),
(32, 'apta', 6),
(33, 'hamrapur', 6),
(34, 'pen', 6),
(35, 'khasu', 6),
(36, 'nagothane', 6),
(37, 'roha', 6),
(38, 'turbhe', 7),
(39, 'koparkhairne', 7),
(40, 'ghansoli', 7),
(41, 'rabale', 7),
(42, 'airoli', 7),
(43, 'kalamboli', 8),
(44, 'navade road', 8),
(45, 'taloja', 8),
(46, 'nilaje', 8),
(47, 'dativili', 8),
(48, 'byculla', 9),
(49, 'cinchpokali', 9),
(50, 'curry road', 9),
(51, 'parel', 9),
(52, 'matunga', 9),
(53, 'sion', 10),
(54, 'vidyavihar', 10),
(55, 'ghatkopar', 10),
(56, 'vikhroli', 10),
(57, 'kanjurmarg', 10),
(58, 'bhandup', 11),
(59, 'nahur', 11),
(60, 'mulund', 11),
(61, 'thane', 11),
(62, 'kalwa', 11),
(63, 'mumbra', 12),
(64, 'diva', 12),
(65, 'kopar', 12),
(66, 'dombivali', 12),
(67, 'thakurli', 12),
(68, 'kalyan', 12),
(69, 'shahad', 13),
(70, 'kharbao', 13),
(71, 'ambivali', 13),
(72, 'titwala', 13),
(73, 'khandivali', 13),
(74, 'vasind', 14),
(75, 'asangaon', 14),
(76, 'atgaon', 14),
(77, 'khardi', 14),
(78, 'kasara', 14),
(79, 'vithalwadi', 15),
(80, 'ulhasnagar', 15),
(81, 'ambernath', 15),
(82, 'badlapur', 15),
(83, 'vangani', 15),
(84, 'shelu', 16),
(85, 'neral', 16),
(86, 'bhivpuri road', 16),
(87, 'karjat', 16),
(88, 'palasdari', 16),
(89, 'kelavali', 17),
(90, 'dalavali', 17),
(91, 'lowjee', 17),
(92, 'khopoli', 17),
(93, 'churchgate', 18),
(94, 'marine line', 18),
(95, 'charni road', 18),
(96, 'grant road', 18),
(97, 'mumbai central', 18),
(98, 'mahalaxmi', 19),
(99, 'lower parel', 19),
(100, 'elphinston road', 19),
(101, 'dadar', 19),
(102, 'matunga road', 19),
(103, 'mahim jn', 20),
(104, 'bandra', 20),
(105, 'khar road', 20),
(106, 'santacruz', 20),
(107, 'juhu', 20),
(108, 'vile parle', 21),
(109, 'andheri', 21),
(110, 'jogeshwari', 21),
(111, 'goregaon', 21),
(112, 'malad', 21),
(113, 'kandivali', 22),
(114, 'borivali', 22),
(115, 'dahisar', 22),
(116, 'mira road', 22),
(117, 'bhayender', 22),
(118, 'naigaon', 23),
(119, 'vasai road', 23),
(120, 'nallasopara', 23),
(121, 'virar', 23),
(122, 'vaitarna', 23),
(123, 'saphale', 24),
(124, 'kelva road', 24),
(125, 'palghar', 24),
(126, 'umardi', 24),
(127, 'boisar', 24),
(128, 'vangaon', 25),
(129, 'dahanu road', 25),
(130, 'asalpha', 26),
(131, 'subhash nagar', 26),
(132, 'sakinaka', 26),
(133, 'marol naka', 26),
(134, 'airport road', 26),
(135, 'chakala(JB nagar)', 27),
(136, 'WEH', 27),
(137, 'DN nagar', 27),
(138, 'versova', 27),
(139, 'nariman point', 18),
(140, 'malbar hill', 18),
(141, 'worli', 19),
(142, 'mazgaon', 18),
(143, 'cuffe parade', 18),
(144, 'colaba', 18),
(145, 'tardeo', 18),
(146, 'haji ali', 19),
(147, 'band stand', 20),
(148, 'powai', 10),
(149, 'chandivali', 10),
(150, 'hiranandani', 10),
(151, 'film city', 21),
(152, 'kalina', 20),
(153, 'kannamwar nagar', 10),
(154, 'aarey colony', 21),
(155, 'girgaon', 18),
(156, 'kamraj nagar', 10),
(157, 'kamani', 10),
(158, 'bharat nagar', 18),
(159, 'BKC', 20),
(160, 'ulwe', 4),
(161, 'kamothe', 5),
(162, 'JNPT', 5),
(163, 'khardanda', 20);

-- --------------------------------------------------------

--
-- Table structure for table `motrage_loan`
--

CREATE TABLE IF NOT EXISTS `motrage_loan` (
  `ml_id` int(11) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `residency_location` varchar(255) DEFAULT NULL,
  `loan_amount` varchar(255) DEFAULT NULL,
  `monthly_income` varchar(255) DEFAULT NULL,
  `property_value` varchar(255) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `active_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ml_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `motrage_loan`
--

INSERT INTO `motrage_loan` (`ml_id`, `full_name`, `email_id`, `mobile`, `dob`, `gender`, `residency_location`, `loan_amount`, `monthly_income`, `property_value`, `created_at`, `updated_at`, `active_status`) VALUES
(1, 'durgesh@gmail.com', 'durgesh@gmail.com', '8268108343', '2018-03-13', 'Male', 'Delhi', '43433343', '34343434', '343434343', '2018-03-29', '2018-03-29', 'a'),
(2, 'fgfhfgh', 'cgfg@gmail.com', '54545454545', '2018-03-20', 'Male', 'Surat', '34343434', '43434343', '434343', '2018-03-29', '2018-03-29', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `personal_loan`
--

CREATE TABLE IF NOT EXISTS `personal_loan` (
  `pl_id` int(11) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `residency_location` varchar(255) DEFAULT NULL,
  `loan_amount` varchar(255) DEFAULT NULL,
  `monthly_income` varchar(255) DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `resident_type` varchar(255) DEFAULT NULL,
  `past_loan` varchar(255) DEFAULT NULL,
  `copany_name` varchar(255) DEFAULT NULL,
  `salary_received` varchar(255) DEFAULT NULL,
  `since_bussiness` varchar(255) DEFAULT NULL,
  `it_return` varchar(255) DEFAULT NULL,
  `turnover` varchar(255) DEFAULT NULL,
  `emi` varchar(255) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `active_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personal_loan`
--

INSERT INTO `personal_loan` (`pl_id`, `full_name`, `email_id`, `mobile`, `dob`, `gender`, `residency_location`, `loan_amount`, `monthly_income`, `occupation`, `resident_type`, `past_loan`, `copany_name`, `salary_received`, `since_bussiness`, `it_return`, `turnover`, `emi`, `created_at`, `updated_at`, `active_status`) VALUES
(1, 'durgesh@gmail.com', 'durgesh@gmail.com', '8268108343', '2018-03-29', 'Male', 'Mumbai', '3434343434', '4343434', 'Salaried', 'Self/Spouse Owned', 'Yes', 'WhizzActSolutions', 'Durgesh', '', '', '', '3434343', '2018-03-29', '2018-03-29', 'a'),
(2, 'durgesh@gmail.com', 'durgesh@gmail.com', '8268108343', '2018-03-29', 'Male', 'Delhi', '3434343434', '454545', 'Self Employed (Business)', 'Self/Spouse Owned', 'Yes', '', '', '', '', '', '45454', '2018-03-29', '2018-03-29', 'a'),
(3, 'durgesh@gmail.com', 'durgesh@gmail.com', '8268108343', '2018-03-29', 'Male', 'Mumbai', '3434343434', '434343', 'Self Employed (Business)', 'Self/Spouse Owned', 'Yes', '', '', 'Less than 2 Years', 'Less than 2 Years', '3434343', '43434', '2018-03-29', '2018-03-29', 'a'),
(4, 'durgesh@gmail.com', 'durgesh@gmail.com', '8268108343', '2018-03-29', 'Male', 'Mumbai', '3434343434', '6565656', 'Self Employed (Professional)', 'Family Owned', 'Yes', '', '', '2 to 5 years', 'Less than 2 Years', '66656565', '5656', '2018-03-29', '2018-03-29', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_details`
--

CREATE TABLE IF NOT EXISTS `visitor_details` (
  `visitor_code` varchar(12) NOT NULL,
  `visitor_ip` varchar(30) DEFAULT NULL,
  `visit_daytime` varchar(25) DEFAULT NULL,
  `visit_date` varchar(11) NOT NULL,
  PRIMARY KEY (`visitor_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visitor_details`
--

INSERT INTO `visitor_details` (`visitor_code`, `visitor_ip`, `visit_daytime`, `visit_date`) VALUES
('1200', '::1', '29-03-2018 18:57:22 PM', '29-03-2018');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

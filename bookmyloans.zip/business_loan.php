<?php
require_once("includes/init.php");
?>
<html>
    <head>
        <title>Business Loan | Book My Loan</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include('topheader.php');?>
        <style>
           .con2 /*background image css don't move this css*/
            {
                background-image: url(images/header-bg.jpg);
                background-size: cover;
                background-repeat: no-repeat;
                height: auto;
                margin-top: 52.4px;
            }
        @import url(https://fonts.googleapis.com/css?family=Open+Sans);

body {
  font-family: 'Open Sans', sans-serif;
  background-color: #efefef;
}

        </style>
    </head>
    <body>
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- Navigation Code starts here -->
        <?php include('navigation.php');?>
        <!-- Navigation Code ends here -->
        <?php include('loan-calculator.php'); ?>
<!-- ------------------------------------------------------------------------------------------ -->

        <div class="container-fluid" style="margin-top: 3.8%; background-color: #156DD1;">
            <br><br>
            <h2 class="font-key text-center col-white">Apply For Business Loan</h2>
            <br>
            <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" name="fname" id="fname" value="<?php echo (empty($_GET['email_id'])) ? '' : $_GET['email_id']; ?>" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Full Name</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" id="mobile" name="mobile" value="<?php echo (empty($_GET['mobile'])) ? '' : $_GET['mobile']; ?>" class="input1" required>
                        <span id="mobileValidation" style="color:#ee5253;font-weight: bold;"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Mobile Number</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="email" id="email" name="email" value="<?php echo (empty($_GET['email_id'])) ? '' : $_GET['email_id']; ?>" class="input1" required>
                        <span id="emailValidation" style="color:#ee5253;font-weight: bold;"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Email Id</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="sel1" class="col-white font-key">Occupation</label>
                      <select name="occupation" id="occupation" onchange="getoccupation(this.value)" class="form-control border_radius_none" id="sel1">
                        <option value="">Select</option>
                        <option value="Salaried">Salaried</option>
                        <option value="Self Employed (Business)">Self Employed (Business)</option>
                        <option value="Self Employed (Professional)">Self Employed (Professional)</option>
                      </select>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="residency_type" class="col-white font-key">Residence Type</label>
                      <select class="form-control border_radius_none" name="residency_type" id="residency_type">
                        <option value="">Select</option>
                        <option value="Self/Spouse Owned">Self/Spouse Owned</option>
                        <option value="Family Owned">Family Owned</option>
                        <option value="Rented Accomodation">Rented Accomodation</option>
                      </select>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="defaultpastloan" class="col-white font-key">Default In Past Loan</label>
                      <select class="form-control border_radius_none" name="defaultpastloan" id="defaultpastloan">
                        <option>Select</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                      </select>
                    </div>
                </div>

            </div>
                <div id="onchangedata" style="display:none;"><div class="row"><div class="col-sm-4"><div class="group1"><input type="text" name="company_name" id="company_name" value="<?php echo (empty($posted['company_name'])) ? '' : $posted['company_name'] ?>"  class="input1" required><span class="highlight1"></span><span class="bar1"></span><label class="label1">Company Name</label></div></div>
                    
                
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="salary_received" class="col-white font-key">Salary Received As</label>
                      <select class="form-control border_radius_none" name="salary_received" id="salary_received">
                        <option value="">Select</option>
                          <optgroup  label="Electronic Tranfer">
                        <option value="HDFC Bank">HDFC Bank</option>
                        <option value="ICIC Bank">ICIC Bank</option>
                        <option value="Axis Bank">Axis Bank</option>
                        <option value="Kotak Bank">Kotak Bank</option>
                        <option value="HSBC Bank">HSBC Bank</option>
                        <option value="Standard Chartered Bank">Standard Chartered Bank</option>
                        <option value="Citi Bank">Citi Bank</option>
                        <option value="Other Bank">Other Bank</option>
                          </optgroup>
                          <option value="Cheque">Cheque</option>
                          <option value="Cash">Cash</option>
                      </select>
                    </div>
                </div>
                    
                    
                    </div></div>
                
                <div id="onchangedata1" style="display:none;">
                <div class="row"><div class="col-sm-4"> <div class="form-group"><label for="inbusinesssince" class="col-white font-key">In Business Since</label><select class="form-control border_radius_none" id="inbusinesssince"  value="<?php echo (empty($posted['inbusinesssince'])) ? '' : $posted['inbusinesssince'] ?>"> <option value="NA">Select</option><option value="Less than 2 Years">Less than 2 years</option><option value="2 to 5 years">2 to 5 years</option><option value="5 to 10 years">5 to 10 years</option></select></div></div>     
                <div class="col-sm-4"> <div class="form-group"><label for="itreturnfile" class="col-white font-key">IT Returns Filed</label><select class="form-control border_radius_none" value="<?php echo (empty($posted['itreturnfile'])) ? '' : $posted['itreturnfile'] ?>" id="itreturnfile"> <option value="NA">Select</option><option value="Less than 2 Years">Less than 2 years</option><option value="2 or more years">2 or more years</option></select></div></div>       
                <div class="col-sm-4"><div class="group1"><input type="text" name="annualturnover" value="<?php echo (empty($posted['annualturnover'])) ? '' : $posted['salary_recived'] ?>"  id="annualturnover" class="input1" required><span class="highlight1"></span><span class="bar1"></span><label class="label1">Annual Turnover</label></div></div></div>
                </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" class="input1"  name="loanamount" value="<?php echo (empty($_GET['amount'])) ? '' : $_GET['amount']; ?>" id="loanamount1" minlenth="5" required><span style="color:red;" id="loanamountmsg"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Loan Amount</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text"  id="txtmonthlyincome" name="txtmonthlyincome" onkeyup="getmothlyincome(this.value)" class="input1" required>
                        <span id="monthlyincome" style="color:#ee5253;font-weight: bold;"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Montly Income</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" name="exitingEMI" id="exitingEMI" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Existing EMI (If any)</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="residency_location" class="col-white font-key">Residency Location</label>
                      <select class="form-control border_radius_none" name="residency_location" id="residency_location">
                          <option>Select</option>
                          <?php
                          $location = Locationdetails::find_all();
                          if($location){
                              foreach($location as $alllocation){
                                  echo '<option value="'.$alllocation->location_name.'">'.strtoupper($alllocation->location_name).'</option>';
                              }
                          }
                          
                          ?>
                      </select>
                    </div>
                </div>
                <div class="col-sm-4">
                    <form>
                    <label class="f16 font-key col-white">Gender</label><br>
                    <label class="radio-inline col-lb"><input type="radio" id="gender" value="Male" name="optradio">Male</label>
                    <label class="radio-inline col-lb"><input type="radio" id="gender"  value="Female" name="optradio">Female</label>
                    </form>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" onfocus="(this.type='date')" placeholder="Date of Birth" name="txtdob" id="txtdob" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Date of Birth</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="checkbox text-center">
                      <label class="col-white font-key f15"><input type="checkbox" value="" checked> I authorize the website and its partners to call or SMS me in connection with my application & I agree to the Privacy Policy and Terms of Use.</label>
                    </div>
                </div>
            </div>
            <center>
                <button type="button" class="btn btn-primary loan-elig col-white" onclick="getBusiness()">Submit</button>
            </center>
            </div>
            <br>
            <div id="popupdiv" class="popupdiv">
                <div class="popupdiv-content">	
                    <center>
                        <div id="popup-main-content">
                        </div>
                    </center>
                </div>
            </div>
            <div class="container">
                <h3 class="text-center col-white">FAQ For Business Loan</h3><br>
                <dl class="accordion">
                    <dt>What is the loan amount that i can avail?</dt>
                    <dd> 
                        <p>An unsecured business loan from Rs. 3 lakhs up to Rs. 50 lakhs may be availed.
                        </p>
                    </dd>

                    <dt>What is the eligibility criterion for a business loan?</dt>
                    <dd>
                        <p>We offer business loans to both professionals and non-professionals, who are self-employed. Among self-employed professionals, we also offer exclusive loans for doctors with special features such as competitive business loan interest rates and quick approval. The customer segment covered under Business Loans is listed below:</p>
                        <ul>
                           <li>Sole Proprietorship</li>
					       <li>Partnership Firm</li>
					       <li>Private Limited Companies</li>
					       <li>Closely held Public Limited Companies</li>
					       <li>Societies</li>
					       <li>Trusts</li>
					       <li>Hospitals, Nursing Homes, Diagnostic Centers, Pathological Labs</li>
                        </ul>
                    </dd>

                    <dt>What is the mode of repayment ?</dt>
                    <dd>
                        <p>You can repay through Post Dated Cheques, Electronic Clearance Service (ECS) or Direct Debit.</p>
                    </dd>
                    
                    <dt>Is the interest rate, fixed or floating?</dt>
                    <dd>
                        <p>The interest rate is fixed.</p>
                    </dd>
                    
                    <dt>What is the tenure available with these loans?</dt>
                    <dd>
                        <p>The business loan tenure can range from 12 months to 48 months.</p>
                    </dd>
                    
                    <dt>What is the tenure available with these loans?</dt>
                    <dd>
                        <p>The business loan tenure can range from 12 months to 48 months.</p>
                    </dd>
                </dl>
            </div>
            
            
        <br>
        </div>
        <!-- footer starts here -->
            <?php include('footer.php');?>
        
        <script src="js/whizz.js"></script>
        <script>
          (function( $ ) {
	$.fn.SimpleAccordion = function () {
		// Cache element
		var accordion = $(this);
		// Fade in on load
		accordion.hide().fadeIn();
		// Open active panel
		accordion.find(".active").show();
		// Listen to onClick
		accordion.find("dt").on("click", function (){
			// Cache current
			var current = $(this).next("dd");
			// Check if not active
			if (current.is(":hidden")) {
				// Open curren panel
				current.slideDown().siblings("dd").slideUp();
			}
		});
	};
})( jQuery );

$(".accordion").SimpleAccordion();
            
            function getoccupation(occupation){
                if(occupation=='Salaried'){
                    $('#onchangedata1').hide();
                    $('#onchangedata').show();
                }
                if(occupation=='Self Employed (Business)'){
                    $('#onchangedata1').show();
                    $('#onchangedata').hide();
                }
                if(occupation=='Self Employed (Professional)'){
                    $('#onchangedata1').show();
                    $('#onchangedata').hide();
                }
                if(occupation==''){
                    $('#onchangedata1').hide();
                    $('#onchangedata').hide();
                }
               
            }
        </script>
    </body>
</html>
<?php
ob_start();
session_start();
require_once('../includes/init.php');
$mode=$_GET['mode'];
if(isset($mode))
{
	if($mode=='i')
	{
		$business=new BusinessLoan();
		$businessnc=BusinessLoan::find_next_code();
		if($businessnc)
		{
            $business->bl_id=$businessnc->bl_id+1;
		}
		else
		{
			$business->bl_id=1;
		}
		$business->full_name = $_POST['full_name'];
		$business->email_id = $_POST['email_id'];
		$business->mobile = $_POST['mobile'];
		$business->dob = $_POST['dob'];
		$business->gender = $_POST['gender'];
		$business->residency_location = $_POST['residency_location'];
		$business->loan_amount = $_POST['loan_amount'];
		$business->monthly_income = $_POST['monthly_income'];
		$business->occupation = $_POST['occupation'];        
		$business->resident_type = $_POST['resident_type'];
		$business->past_loan = $_POST['past_loan'];
        $business->copany_name = $_POST['copany_name'];       
		$business->salary_received = $_POST['salary_received']; 
		$business->since_bussiness = $_POST['since_bussiness'];        
		$business->it_return = $_POST['it_return'];
		$business->turnover = $_POST['turnover'];
		$business->emi = $_POST['emi'];
		$business->created_at = date('Y-m-d');
		$business->updated_at = date('Y-m-d');
		$business->active_status = 'a';
		if($business->save()){
         
            /**************************mail**************************/
	        $to = 'enquiry@bookmyloans.co.in';
            $subject = 'New Enquiry From Website for Business Loan '.$_POST['email_id'].'.';
            $message = '
            <html>
            <head>
            <title>Business Loan Enquiry From Website</title>
            </head>
            <body>
                <cnter>
                    <br>
                    <table border="1" style="width:70%;">
                        <tr>
                            <th style="background:#8080ff;padding:10px;" colspan="2"><h2>Business Loan Enquiry From Website.</h2></th>
                        </tr>
                        <tr>
                            <td>Apply Date</td>
                            <td>'.date('Y-m-d').'</td>
                        </tr>
                        <tr>
                            <td>User Name</td>
                            <td>'.$_POST['full_name'].'</td>
                        </tr>
                        <tr>
                            <td>User Email ID</td>
                            <td>'.$_POST['email_id'].'</td>
                        </tr>
                        <tr>
                            <td>User Mobile</td>
                            <td>'.$_POST['mobile'].'</td>
                        </tr>
                        <tr>
                            <td>User Date of Birth</td>
                            <td>'.$_POST['dob'].'</td>
                        </tr>
                        <tr>
                            <td>User Gender</td>
                            <td>'.$_POST['gender'].'</td>
                        </tr>
                        <tr>
                            <td>User Residence Location</td>
                            <td>'.$_POST['residency_location'].'</td>
                        </tr>
                        <tr>
                            <td>Loan Amount</td>
                            <td>'.$_POST['loan_amount'].'</td>
                        </tr>
                        <tr>
                            <td>Monthly Income</td>
                            <td>'.$_POST['monthly_income'].'</td>
                        </tr>
                        <tr>
                            <td>Occupation</td>
                            <td>'.$_POST['occupation'].'</td>
                        </tr>
                        <tr>
                            <td>Resident Type</td>
                            <td>'.$_POST['resident_type'].'</td>
                        </tr>
                        <tr>
                            <td>Past Loan</td>
                            <td>'.$_POST['past_loan'].'</td>
                        </tr>
                        <tr>
                            <td>Company Name</td>
                            <td>'.$_POST['copany_name'].'</td>
                        </tr>
                        <tr>
                            <td>Salary Received</td>
                            <td>'.$_POST['salary_received'].'</td>
                        </tr>
                        <tr>
                            <td>Since Bussiness</td>
                            <td>'.$_POST['since_bussiness'].'</td>
                        </tr>
                        <tr>
                            <td>IT Return</td>
                            <td>'.$_POST['it_return'].'</td>
                        </tr>
                        <tr>
                            <td>Turn Over</td>
                            <td>'.$_POST['turnover'].'</td>
                        </tr>
                        <tr>
                            <td>EMI</td>
                            <td>'.$_POST['emi'].'</td>
                        </tr>
                    </table>
                </center>
            </body>
            </html>
            ';

            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

            // More headers
            $headers .= 'From: '.$_POST['email_id'] . "\r\n";
            $headers .= 'Cc: salunke.rajesh@gmail.com' . "\r\n";
            mail($to,$subject,$message,$headers);
            /************************end mail************************/
        echo 'success';
        }
	}
    if($mode=='d')
	{
		$category=new BusinessLoan();
		
		$category->bl_id=$_POST['bl_id'];
		if($category->delete())
		{
			redirect_to("../admin/secure/businessloans.php");
		}
	}
}
?>
<?php
ob_start();
$amount = $_POST['amount'];
$fname = $_POST['fname'];
$email_id = $_POST['email_id'];
$mobile = $_POST['mobile'];
    
    
if($_POST['optradio']=="Home Loan"){
   header('Location: ../home_loan.php?amount='.$amount.'&fname='.$fname.'&email_id='.$email_id.'&mobile='.$mobile);
}
if($_POST['optradio']=="Balance Transfer"){
   header('Location: ../balance_transfer.php?amount='.$amount.'&fname='.$fname.'&email_id='.$email_id.'&mobile='.$mobile);
}
if($_POST['optradio']=="Mortgage Loan"){
    header('Location: ../motrageage_loan.php?amount='.$amount.'&fname='.$fname.'&email_id='.$email_id.'&mobile='.$mobile);
}
if($_POST['optradio']=="Personal Loan"){
    header('Location: ../personal_loan.php?amount='.$amount.'&fname='.$fname.'&email_id='.$email_id.'&mobile='.$mobile);
}
if($_POST['optradio']=="Business Loan"){
    header('Location: ../business_loan.php?amount='.$amount.'&fname='.$fname.'&email_id='.$email_id.'&mobile='.$mobile);
}
?>
<?php
ob_start();
session_start();
require_once('../includes/init.php');
$mode=$_GET['mode'];
if(isset($mode))
{
	if($mode=='i')
	{
		$home=new HomeLoan();
		$homenc=HomeLoan::find_next_code();
		if($homenc)
		{
            $home->home_id=$homenc->home_id+1;
		}
		else
		{
			$home->home_id=1;
		}
		$home->full_name = $_POST['full_name'];
		$home->email_id = $_POST['email_id'];
		$home->mobile = $_POST['mobile'];
		$home->dob = $_POST['txtdob'];
		$home->gender = $_POST['optradio'];
		$home->purpose = $_POST['purpose'];
		$home->occupation = $_POST['occupation'];
        $home->copany_name = $_POST['copany_name'];       
		$home->salary_received = $_POST['salary_received']; 
		$home->since_bussiness = $_POST['since_bussiness'];        
		$home->it_return = $_POST['it_return'];
		$home->turnover = $_POST['turnover'];
		$home->residency_location = $_POST['residency_location'];
		$home->loan_amount = $_POST['loanamount'];
		$home->monthly_income = $_POST['txtmonthlyincome'];
		$home->co_applicant = $_POST['coapplicant1'];
        $home->coapp_income = $_POST['coapp_income'];       
		$home->property_finalized = $_POST['propertyradio']; 
		$home->property_location = $_POST['propert_location'];        
		$home->property_value = $_POST['property_value'];
		$home->property_name = $_POST['property_name'];
		$home->created_at = date('Y-m-d');
		$home->updated_at = date('Y-m-d');
		$home->active_status = 'a';
		if($home->save())
        {
            /**************************mail**************************/
	        $to = 'enquiry@bookmyloans.co.in';
            $subject = 'New Enquiry From Website for Home Loan '.$_POST['email_id'].'.';
            $message = '
            <html>
            <head>
            <title>Home Loan Enquiry From Website</title>
            </head>
            <body>
                <cnter>
                    <br>
                    <table border="1" style="width:70%;">
                        <tr>
                            <th style="background:#8080ff;padding:10px;" colspan="2"><h2>Home Loan Enquiry From Website.</h2></th>
                        </tr>
                        <tr>
                            <td>Apply Date</td>
                            <td>'.date('Y-m-d').'</td>
                        </tr>
                        <tr>
                            <td>User Name</td>
                            <td>'.$_POST['full_name'].'</td>
                        </tr>
                        <tr>
                            <td>User Email ID</td>
                            <td>'.$_POST['email_id'].'</td>
                        </tr>
                        <tr>
                            <td>User Mobile</td>
                            <td>'.$_POST['mobile'].'</td>
                        </tr>
                        <tr>
                            <td>User Date of Birth</td>
                            <td>'.$_POST['txtdob'].'</td>
                        </tr>
                        <tr>
                            <td>User Gender</td>
                            <td>'.$_POST['optradio'].'</td>
                        </tr>
                        <tr>
                            <td>User Purpose</td>
                            <td>'.$_POST['purpose'].'</td>
                        </tr>
                        <tr>
                            <td>User Occupation</td>
                            <td>'.$_POST['occupation'].'</td>
                        </tr>
                        <tr>
                            <td>User Residence Location</td>
                            <td>'.$_POST['residency_location'].'</td>
                        </tr>
                        <tr>
                            <td>Loan Amount</td>
                            <td>'.$_POST['loanamount'].'</td>
                        </tr>
                        <tr>
                            <td>Monthly Income</td>
                            <td>'.$_POST['txtmonthlyincome'].'</td>
                        </tr>
                        <tr>
                            <td>Co-Applicant</td>
                            <td>'.$_POST['coapplicant1'].'</td>
                        </tr>
                        <tr>
                            <td>Co-Applicant Income</td>
                            <td>'.$_POST['coapp_income'].'</td>
                        </tr>
                        <tr>
                            <td>Property Finalized</td>
                            <td>'.$_POST['propertyradio'].'</td>
                        </tr>
                        <tr>
                            <td>Property Location</td>
                            <td>'.$_POST['propert_location'].'</td>
                        </tr>
                        <tr>
                            <td>Property Value</td>
                            <td>'.$_POST['property_value'].'</td>
                        </tr>
                        <tr>
                            <td>Property Name</td>
                            <td>'.$_POST['property_name'].'</td>
                        </tr>
                    </table>
                </center>
            </body>
            </html>
            ';

            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

            // More headers
            $headers .= 'From: '.$_POST['email_id'] . "\r\n";
            $headers .= 'Cc: salunke.rajesh@gmail.com' . "\r\n";
            mail($to,$subject,$message,$headers);
            /************************end mail************************/
        }
        echo 'success';
	}
    //echo 'error';
    
	if($mode=='d')
	{
		$category=new HomeLoan();
		
		$category->home_id=$_POST['home_id'];
		if($category->delete())
		{
			redirect_to("../admin/secure/homeloans.php");
		}
	}
}
?>
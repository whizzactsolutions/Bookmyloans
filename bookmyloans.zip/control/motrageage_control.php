<?php
ob_start();
session_start();
require_once('../includes/init.php');
$mode=$_GET['mode'];
if(isset($mode))
{
	if($mode=='i')
	{
		$motrage=new MotrageLoan();
		$motragenc=MotrageLoan::find_next_code();
		if($motragenc)
		{
            $motrage->ml_id=$motragenc->ml_id+1;
		}
		else
		{
			$motrage->ml_id=1;
		}
		$motrage->full_name = $_POST['full_name'];
		$motrage->email_id = $_POST['email_id'];
		$motrage->mobile = $_POST['mobile'];
		$motrage->dob = $_POST['dob'];
		$motrage->gender = $_POST['gender'];
		$motrage->residency_location = $_POST['residency_location'];
		$motrage->loan_amount = $_POST['loan_amount'];
		$motrage->monthly_income = $_POST['monthly_income'];
        $motrage->occupation = $_POST['occupation'];
		$motrage->property_value = $_POST['property_value'];
		$motrage->created_at = date('Y-m-d');
		$motrage->updated_at = date('Y-m-d');
		$motrage->active_status = 'a';
		if($motrage->save()){
            
            /**************************mail**************************/
	        $to = 'enquiry@bookmyloans.co.in';
            $subject = 'New Enquiry From Website for Home Loan '.$_POST['email_id'].'.';
            $message = '
            <html>
            <head>
            <title>Home Loan Enquiry From Website</title>
            </head>
            <body>
                <cnter>
                    <br>
                    <table border="1" style="width:70%;">
                        <tr>
                            <th style="background:#8080ff;padding:10px;" colspan="2"><h2>Motrageage Loan Enquiry From Website.</h2></th>
                        </tr>
                        <tr>
                            <td>Apply Date</td>
                            <td>'.date('Y-m-d').'</td>
                        </tr>
                        <tr>
                            <td>User Name</td>
                            <td>'.$_POST['full_name'].'</td>
                        </tr>
                        <tr>
                            <td>User Email ID</td>
                            <td>'.$_POST['email_id'].'</td>
                        </tr>
                        <tr>
                            <td>User Mobile</td>
                            <td>'.$_POST['mobile'].'</td>
                        </tr>
                        <tr>
                            <td>User Date of Birth</td>
                            <td>'.$_POST['dob'].'</td>
                        </tr>
                        <tr>
                            <td>User Gender</td>
                            <td>'.$_POST['gender'].'</td>
                        </tr>
                        <tr>
                            <td>User Residence Location</td>
                            <td>'.$_POST['residency_location'].'</td>
                        </tr>
                        <tr>
                            <td>Loan Amount</td>
                            <td>'.$_POST['loan_amount'].'</td>
                        </tr>
                        <tr>
                            <td>Monthly Income</td>
                            <td>'.$_POST['monthly_income'].'</td>
                        </tr>
                        <tr>
                            <td>Occupation</td>
                            <td>'.$_POST['occupation'].'</td>
                        </tr>
                        <tr>
                            <td>Property Value</td>
                            <td>'.$_POST['property_value'].'</td>
                        </tr>'.$_POST['property_name'].'</td>
                        </tr>
                    </table>
                </center>
            </body>
            </html>
            ';

            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

            // More headers
            $headers .= 'From: '.$_POST['email_id'] . "\r\n";
            $headers .= 'Cc: salunke.rajesh@gmail.com' . "\r\n";
            mail($to,$subject,$message,$headers);
            /************************end mail************************/
            echo 'success';
        }
	}
    if($mode=='d')
	{
		$category=new MotrageLoan();
		
		$category->ml_id=$_POST['ml_id'];
		if($category->delete())
		{
			redirect_to("../admin/secure/mortgagesloans.php");
		}
	}
}
?>
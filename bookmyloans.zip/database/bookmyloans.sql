create table admin
(
admin_id int primary key,
name varchar(255),
email varchar(255),
passowrd varchar(255),
last_login varchar(255),
password varchar(255)
);

create table homeloans
(
home_id int primary key,
full_name varchar(255),
email_id varchar(255),
mobile varchar(255),
dob varchar(255),
gender varchar(255),
purpose varchar(255),
occupation varchar(255),
residency_location varchar(255),
loan_amount varchar(255),
monthly_income varchar(255),
co_applicant varchar(255),
property_finalized varchar(255),
property_location varchar(255),
property_value varchar(255),
property_name varchar(255),
created_at date,
updated_at date,
active_status varchar(255)
);

create table motrage_loan
(
ml_id int primary key,
full_name varchar(255),
email_id varchar(255),
mobile varchar(255),
dob varchar(255),
gender varchar(255),
residency_location varchar(255),
loan_amount varchar(255),
monthly_income varchar(255),
property_value varchar(255),
created_at date,
updated_at date,
active_status varchar(255)
);

create table personal_loan
(
pl_id int primary key,
full_name varchar(255),
email_id varchar(255),
mobile varchar(255),
dob varchar(255),
gender varchar(255),
residency_location varchar(255),
loan_amount varchar(255),
monthly_income varchar(255),
occupation varchar(255),
resident_type varchar(255),
past_loan varchar(255),
copany_name varchar(255),
salary_received varchar(255),
since_bussiness varchar(255),
it_return varchar(255),
turnover varchar(255),
emi varchar(255),

);

create table business_loan
(
bl_id int primary key,
full_name varchar(255),
email_id varchar(255),
mobile varchar(255),
dob varchar(255),
gender varchar(255),
residency_location varchar(255),
loan_amount varchar(255),
monthly_income varchar(255),
occupation varchar(255),
resident_type varchar(255),
past_loan varchar(255),
copany_name varchar(255),
salary_received varchar(255),
since_bussiness varchar(255),
it_return varchar(255),
turnover varchar(255),
emi varchar(255),

);
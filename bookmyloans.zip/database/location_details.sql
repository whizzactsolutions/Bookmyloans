-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2018 at 03:00 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `careayush`
--

-- --------------------------------------------------------

--
-- Table structure for table `location_details`
--

CREATE TABLE IF NOT EXISTS `location_details` (
  `location_code` int(12) NOT NULL,
  `location_name` varchar(20) DEFAULT NULL,
  `zone_code` int(12) DEFAULT NULL,
  PRIMARY KEY (`location_code`),
  UNIQUE KEY `location_name` (`location_name`),
  KEY `zone_code` (`zone_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location_details`
--

INSERT INTO `location_details` (`location_code`, `location_name`, `zone_code`) VALUES
(1, 'CST', 1),
(2, 'masjid', 1),
(3, 'fort', 1),
(4, 'sandhurst road', 1),
(5, 'dockyard road', 1),
(6, 'reay road', 1),
(7, 'cotton green', 2),
(8, 'sewri', 2),
(9, 'wadala road', 2),
(10, 'gtb nagar', 2),
(11, 'antop hill', 2),
(12, 'chunabhatti', 2),
(13, 'king circle', 2),
(14, 'kurla', 3),
(15, 'tilak nagar', 3),
(16, 'chembur', 3),
(17, 'govandi', 3),
(18, 'suman nagar', 3),
(19, 'mankhurd', 3),
(20, 'vashi', 4),
(21, 'sanpada', 4),
(22, 'palm beach road', 4),
(23, 'jui nagar', 4),
(24, 'nerul', 4),
(25, 'sea wood', 4),
(26, 'belapur', 5),
(27, 'kharghar', 5),
(28, 'khandeshwar', 5),
(29, 'panvel', 5),
(30, 'new panvel', 5),
(31, 'passyani', 5),
(32, 'apta', 6),
(33, 'hamrapur', 6),
(34, 'pen', 6),
(35, 'khasu', 6),
(36, 'nagothane', 6),
(37, 'roha', 6),
(38, 'turbhe', 7),
(39, 'koparkhairne', 7),
(40, 'ghansoli', 7),
(41, 'rabale', 7),
(42, 'airoli', 7),
(43, 'kalamboli', 8),
(44, 'navade road', 8),
(45, 'taloja', 8),
(46, 'nilaje', 8),
(47, 'dativili', 8),
(48, 'byculla', 9),
(49, 'cinchpokali', 9),
(50, 'curry road', 9),
(51, 'parel', 9),
(52, 'matunga', 9),
(53, 'sion', 10),
(54, 'vidyavihar', 10),
(55, 'ghatkopar', 10),
(56, 'vikhroli', 10),
(57, 'kanjurmarg', 10),
(58, 'bhandup', 11),
(59, 'nahur', 11),
(60, 'mulund', 11),
(61, 'thane', 11),
(62, 'kalwa', 11),
(63, 'mumbra', 12),
(64, 'diva', 12),
(65, 'kopar', 12),
(66, 'dombivali', 12),
(67, 'thakurli', 12),
(68, 'kalyan', 12),
(69, 'shahad', 13),
(70, 'kharbao', 13),
(71, 'ambivali', 13),
(72, 'titwala', 13),
(73, 'khandivali', 13),
(74, 'vasind', 14),
(75, 'asangaon', 14),
(76, 'atgaon', 14),
(77, 'khardi', 14),
(78, 'kasara', 14),
(79, 'vithalwadi', 15),
(80, 'ulhasnagar', 15),
(81, 'ambernath', 15),
(82, 'badlapur', 15),
(83, 'vangani', 15),
(84, 'shelu', 16),
(85, 'neral', 16),
(86, 'bhivpuri road', 16),
(87, 'karjat', 16),
(88, 'palasdari', 16),
(89, 'kelavali', 17),
(90, 'dalavali', 17),
(91, 'lowjee', 17),
(92, 'khopoli', 17),
(93, 'churchgate', 18),
(94, 'marine line', 18),
(95, 'charni road', 18),
(96, 'grant road', 18),
(97, 'mumbai central', 18),
(98, 'mahalaxmi', 19),
(99, 'lower parel', 19),
(100, 'elphinston road', 19),
(101, 'dadar', 19),
(102, 'matunga road', 19),
(103, 'mahim jn', 20),
(104, 'bandra', 20),
(105, 'khar road', 20),
(106, 'santacruz', 20),
(107, 'juhu', 20),
(108, 'vile parle', 21),
(109, 'andheri', 21),
(110, 'jogeshwari', 21),
(111, 'goregaon', 21),
(112, 'malad', 21),
(113, 'kandivali', 22),
(114, 'borivali', 22),
(115, 'dahisar', 22),
(116, 'mira road', 22),
(117, 'bhayender', 22),
(118, 'naigaon', 23),
(119, 'vasai road', 23),
(120, 'nallasopara', 23),
(121, 'virar', 23),
(122, 'vaitarna', 23),
(123, 'saphale', 24),
(124, 'kelva road', 24),
(125, 'palghar', 24),
(126, 'umardi', 24),
(127, 'boisar', 24),
(128, 'vangaon', 25),
(129, 'dahanu road', 25),
(130, 'asalpha', 26),
(131, 'subhash nagar', 26),
(132, 'sakinaka', 26),
(133, 'marol naka', 26),
(134, 'airport road', 26),
(135, 'chakala(JB nagar)', 27),
(136, 'WEH', 27),
(137, 'DN nagar', 27),
(138, 'versova', 27),
(139, 'nariman point', 18),
(140, 'malbar hill', 18),
(141, 'worli', 19),
(142, 'mazgaon', 18),
(143, 'cuffe parade', 18),
(144, 'colaba', 18),
(145, 'tardeo', 18),
(146, 'haji ali', 19),
(147, 'band stand', 20),
(148, 'powai', 10),
(149, 'chandivali', 10),
(150, 'hiranandani', 10),
(151, 'film city', 21),
(152, 'kalina', 20),
(153, 'kannamwar nagar', 10),
(154, 'aarey colony', 21),
(155, 'girgaon', 18),
(156, 'kamraj nagar', 10),
(157, 'kamani', 10),
(158, 'bharat nagar', 18),
(159, 'BKC', 20),
(160, 'ulwe', 4),
(161, 'kamothe', 5),
(162, 'JNPT', 5),
(163, 'khardanda', 20);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `location_details`
--
ALTER TABLE `location_details`
  ADD CONSTRAINT `location_details_ibfk_1` FOREIGN KEY (`zone_code`) REFERENCES `zone_details` (`zone_code`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

 <div class="container-fluid" style="padding: 0;">
           <nav class="navbar navbar-default nav-col">
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar1">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                        
                  </button>
                </div>
                <div class="collapse navbar-collapse text-right" id="myNavbar1">
                  <ul class="nav navbar-nav">
                    <li class="nav-seperator li_hover"><a href="#know_about" style="font-size:12px;">About</a></li>
                    <li class="nav-seperator li_hover"><a href="home_loan.php" style="font-size:12px;">Home loan</a></li>
                       <li class="nav-seperator li_hover"><a href="motrageage_loan.php" style="font-size:12px;">Mortgages Loan</a></li>
                       <li class="nav-seperator li_hover"><a href="home_loan.php" style="font-size:12px;">Balance Transfer</a></li>
                       <li class="nav-seperator li_hover"><a href="personal_loan.php" style="font-size:12px;">Personal loan</a></li>
                       <li class="nav-seperator li_hover"><a href="business_loan.php" style="font-size:12px;">Business loan</a></li>
                       <li class="nav-seperator li_hover"><a href="#contact" style="font-size:12px;">Contact US</a></li>
                  </ul>
                </div>
            </nav>
            </div>
            <div class="container-fluid" style="background-color: #2c3e50; padding: 1%; margin-top:-20px;">
					<div class="col-sm-8 col-xs-12">
                        <p class="text-right">
                            <script language=javascript>
                              today=new Date();
                              y0=today.getFullYear();
                              document.write('<center><span style="font: 10pt arial,sans-serif;color:#fff;">Copyright &copy; '+y0+', bookmyloans.co.in All Rights Reserved. | <a href="privacy_security.php" style="color:#fff;"><u>Security Policy</U></a> | <a href="terms_conditions.php" style="color:#fff;"><u>Terms & Conditions</u></a></span></center>');
                            </script>
                        </p>
					</div>
					<div class="col-sm-4 col-xs-12">
						<p style="font: 10pt arial,sans-serif;margin-right:20px;margin-top:12px;" class="text-right col-white">Design &amp; Developed By 
				        <a href="http://www.whizzactsolutions.com" target="_blank" style="color:#fff;">WhizzActSolutions</a></p>
					</div>
               </div>
<style>.async-hide { opacity: 0 !important} </style>
<script>(function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
(a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
})(window,document.documentElement,'async-hide','dataLayer',4000,
{'GTM-KFB8CW8':true});</script>
        <!-- footer starts here -->
<!-- ------------------------------------------------------------------------------------------ -->
    <!-- script for on hover dropdown menu starts here -->
      <script>
          $('ul.nav li.dropdown').hover(function() {
            $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
          }, function() {
            $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
          });
      </script>
    <!-- script for on hover dropdown menu ends here -->
<!-- ------------------------------------------------------------------------------------------ -->
    <!-- script for smooth scroll on a click -->
        <script>
$(document).ready(function(){
  $("a").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
        window.location.hash = hash;
      });
    }
  });
});
</script>
    
    <a href="#" class="scrollToTop"><i class="fa fa-angle-double-up" aria-hidden="true"></i></a>
    <script>
        $(document).ready(function(){
	
	//Check to see if the window is top if not then display button
	$(window).scroll(function(){
		if ($(this).scrollTop() > 100) {
			$('.scrollToTop').fadeIn();
		} else {
			$('.scrollToTop').fadeOut();
		}
	});
	
	//Click event to scroll to top
	$('.scrollToTop').click(function(){
		$('html, body').animate({scrollTop : 0},800);
		return false;
	});
	
});
    </script>\
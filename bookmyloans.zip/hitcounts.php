<?php
require_once('includes/init.php');
$visitor=new Visitor();
$vnc=Visitor::find_next_code();
if($vnc)
{
	foreach($vnc as $nextcode)
	{
		$cntl=strlen($nextcode->visitor_code);
		echo "<table><tr>";
		//echo "<td colspan=3 STYLE='COLOR:#006AD5;FONT-WEIGHT:BOLDER;FONT-SIZE:12PX;'>VISITOR </td>";
		for($x=1;$x<=11;$x++)
		{
		if(substr($nextcode->visitor_code,$x,1)==0)
		{
			echo "<td>0</td>";
		}
		if(substr($nextcode->visitor_code,$x,1)==1)
		{
			echo "<td>1</td>";
		}
		if(substr($nextcode->visitor_code,$x,1)==2)
		{
			echo "<td>2</td>";
		}
		if(substr($nextcode->visitor_code,$x,1)==3)
		{
			echo "<td>3</td>";
		}
		if(substr($nextcode->visitor_code,$x,1)==4)
		{
			echo "<td>4</td>";
		}
		if(substr($nextcode->visitor_code,$x,1)==5)
		{
			echo "<td>5</td>";
		}
		if(substr($nextcode->visitor_code,$x,1)==6)
		{
			echo "<td>6/td>";
		}
		if(substr($nextcode->visitor_code,$x,1)==7)
		{
			echo "<td>7</td>";
		}
		if(substr($nextcode->visitor_code,$x,1)==8)
		{
			echo "<td>8</td>";
		}
		if(substr($nextcode->visitor_code,$x,1)==9)
		{
			echo "<td>9</td>";
		}
		}
		echo "</tr></table>";
	}
}

?>
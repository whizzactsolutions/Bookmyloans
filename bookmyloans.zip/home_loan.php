<?php
require_once("includes/init.php");
?>
<html>
    <head>
        <title>Home Loan | Book My Loan</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include('topheader.php');?>
        <style>
           .con2 /*background image css don't move this css*/
            {
                background-image: url(images/header-bg.jpg);
                background-size: cover;
                background-repeat: no-repeat;
                height: auto;
                margin-top: 52.4px;
            }
        @import url(https://fonts.googleapis.com/css?family=Open+Sans);

body {
  font-family: 'Open Sans', sans-serif;
  background-color: #efefef;
}

        </style>
    </head>
    <body>
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- Navigation Code starts here -->
        <?php include('navigation.php');?>
        <!-- Navigation Code ends here -->
       <?php include('loan-calculator.php'); ?>
<!-- ------------------------------------------------------------------------------------------ -->

        <div class="container-fluid" style="margin-top: 3.8%; background-color: #156DD1;">
            <br><br>
            <h2 class="font-key text-center col-white">Apply For Home Loan</h2>
            <br>
            <form action="control/homeloan_control.php?mode=i" method="post">
            <div class="container">
            <div class="row">
               <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" name="full_name" id="full_name" value="<?php echo (empty($_GET['fname'])) ? '' : $_GET['fname']; ?>" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Full Name</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="email" id="email_id" name="email_id" value="<?php echo (empty($_GET['email_id'])) ? '' : $_GET['email_id']; ?>" class="input1" required>
                        <span id="emailValidation" style="color:#ee5253;font-weight: bold;"></span>
                      <span class="highlight1"></span>
                      <span class="bar1" ></span>
                      <label class="label1">Email ID</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" id="mobile" name="mobile" value="<?php echo (empty($_GET['mobile'])) ? '' : $_GET['mobile']; ?>" class="input1" required>
                        <span id="mobileValidation" style="color:#ee5253;font-weight: bold;"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Mobile Number</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1"> 
                      <input type="text" onfocus="(this.type='date')" placeholder="Date of Birth" name="txtdob" id="txtdob" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Date of Birth</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <form>
                    <label class="f16 font-key col-white">Gender</label><br>
                    <label class="radio-inline col-lb"><input type="radio" id="gender" value="Male" name="optradio">Male</label>
                    <label class="radio-inline col-lb"><input type="radio" id="gender"  value="Female" name="optradio">Female</label>
                    </form>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="sel1" class="col-white font-key">Purpose</label>
                      <select name="purpose" id="purpose" class="form-control border_radius_none" id="sel1">
                        <option>Select</option>
                        <option value="Buy Ready to occupy Home">Buy Ready to occupy Home</option>
                        <option value="Buy Under-Construction Home">Buy Under-Construction Home</option>
                        <option value="Buy A Plot Of Land">Buy A Plot Of Land</option>
                        <option value="Transfer Home Loan">Balance Transfer</option>
                      </select>
                    </div>
                </div>
                </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="occupation" class="col-white font-key">Occupation</label>
                      <select name="occupation" id="occupation" onchange="getoccupation(this.value)"  class="form-control border_radius_none" >
                        <option>Select</option>
                        <option value="Salaried">Salaried</option>
                        <option value="Self Employed (Business)">Self Employed (Business)</option>
                        <option value="Self Employed (Professional)">Self Employed (Professional)</option>
                        <option value="Retired">Retired</option>
                        <option value="House Wife">House Wife</option>
                      </select>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="residency_location" class="col-white font-key">Residency Location</label>
                      <select class="form-control border_radius_none" name="residency_location" id="residency_location">
                        <option>Select</option>
                          <?php
                          $location = Locationdetails::find_all();
                          if($location){
                              foreach($location as $alllocation){
                                  echo '<option value="'.$alllocation->location_name.'">'.strtoupper($alllocation->location_name).'</option>';
                              }
                          }
                          
                          ?>
                      </select>
                    </div>
                </div> 
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" class="input1" name="loanamount" value="<?php echo (empty($_GET['amount'])) ? '' : $_GET['amount']; ?>" id="loanamount" onkeyup="getloanamount(this.value)" required><span style="color:red;" id="loanamountmsg"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Loan Amount</label>
                    </div>
                </div>
            </div>
                <div id="onchangedata" style="display:none;"><div class="row"><div class="col-sm-4"><div class="group1"><input type="text" name="company_name" id="company_name" value="<?php echo (empty($posted['company_name'])) ? '' : $posted['company_name'] ?>"  class="input1" required><span class="highlight1"></span><span class="bar1"></span><label class="label1">Company Name</label></div></div>
                    
                
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="salary_received" class="col-white font-key">Salary Received As</label>
                      <select class="form-control border_radius_none" name="salary_recived" id="salary_recived">
                        <option value="">Select</option>
                          <optgroup  label="Electronic Tranfer">
                        <option value="HDFC Bank">HDFC Bank</option>
                        <option value="ICIC Bank">ICIC Bank</option>
                        <option value="Axis Bank">Axis Bank</option>
                        <option value="Kotak Bank">Kotak Bank</option>
                        <option value="HSBC Bank">HSBC Bank</option>
                        <option value="Standard Chartered Bank">Standard Chartered Bank</option>
                        <option value="Citi Bank">Citi Bank</option>
                        <option value="Other Bank">Other Bank</option>
                          </optgroup>
                          <option value="Cheque">Cheque</option>
                          <option value="Cash">Cash</option>
                      </select>
                    </div>
                </div>
                    
                    
                    </div></div>
                
                <div id="onchangedata1" style="display:none;">
                <div class="row"><div class="col-sm-4"> <div class="form-group"><label for="inbusinesssince" class="col-white font-key">In Business Since</label><select class="form-control border_radius_none" id="inbusinesssince"  value="<?php echo (empty($posted['inbusinesssince'])) ? '' : $posted['inbusinesssince'] ?>"> <option value="NA">Select</option><option value="Less than 2 Years">Less than 2 years</option><option value="2 to 5 years">2 to 5 years</option><option value="5 to 10 years">5 to 10 years</option></select></div></div>     
                <div class="col-sm-4"> <div class="form-group"><label for="itreturnfile" class="col-white font-key">IT Returns Filed</label><select class="form-control border_radius_none" value="<?php echo (empty($posted['itreturnfile'])) ? '' : $posted['itreturnfile'] ?>" id="itreturnfile"> <option value="NA">Select</option><option value="Less than 2 Years">Less than 2 years</option><option value="2 or more years">2 or more years</option></select></div></div>       
                <div class="col-sm-4"><div class="group1"><input type="text" name="annualturnover" value="<?php echo (empty($posted['annualturnover'])) ? '' : $posted['salary_recived'] ?>"  id="annualturnover" class="input1" required><span class="highlight1"></span><span class="bar1"></span><label class="label1">Annual Turnover</label></div></div></div>
                </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" id="txtmonthlyincome" name="txtmonthlyincome" onkeyup="getmothlyincome(this.value)" class="input1" required>
                        <span id="monthlyincome" style="color:#ee5253;font-weight: bold;"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Monthly Income</label>
                    </div>
                </div>
                <div class="col-sm-4" style="margin-top:30px;">
                    <form>
                    <label class="f16 font-key col-white">Co-Applicant</label>
                    <label class="radio-inline col-lb"><input type="radio" name="coapplicant1" value="Yes" id="coapplicant">Yes</label>
                    <label class="radio-inline col-lb"><input type="radio" name="coapplicant1" value="No" id="coapplicant">No</label>
                    </form>
                </div>
                <div style="display:none;" id="coapplicantid">
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" class="input1" name="coapp_income" id="coapp_income" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Co-App Income</label>
                    </div>
                </div>
                </div>
           </div>
            <div class="row">
                <div class="col-sm-4">
                    <label class="f16 font-key col-white">Property Finalized</label>&nbsp;&nbsp;&nbsp;
                    <label class="radio-inline col-lb"><input type="radio" value="Yes" name="propertyradio" id="propertyradio"  data-validation="required" data-validation-error-msg="Property Finalized is required!">Yes</label>
                    <label class="radio-inline col-lb"><input type="radio" value="No" name="propertyradio" id="propertyradio">No</label>
                </div>
                <div style="display:none;" id="propertydata">
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="sel1" class="col-white font-key">Property Location</label>
                      <select name="propert_location" id="propert_location" class="form-control border_radius_none" id="sel1">
                        <option>Select</option>
                          <?php
                          $location = Locationdetails::find_all();
                          if($location){
                              foreach($location as $alllocation){
                                  echo '<option value="'.$alllocation->location_name.'">'.strtoupper($alllocation->location_name).'</option>';
                              }
                          }
                          
                          ?>
                      </select>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" id="property_value" name="property_value" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Property Value</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" name="property_name" id="property_name" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Property Name</label>
                    </div>
                </div>
                </div>
                
                </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="checkbox text-center">
                      <label class="col-white font-key f15"><input type="checkbox" value="" checked> I authorize the website and its partners to call or SMS me in connection with my application & I agree to the Privacy Policy and Terms of Use.</label>
                    </div>
                </div>
            </div>
            <center>
                <button type="button" class="btn btn-primary loan-elig col-white" onclick="gethomeloan()" id="submitbtn">Submit</button>
                <!--<input type="submit" class="btn btn-primary loan-elig col-white" value="Submit">-->
            </center>
            </div>
            </form>
            
            <div id="popupdiv" class="popupdiv">
                <div class="popupdiv-content">	
                    <center>
                        <div id="popup-main-content">
                        </div>
                    </center>
                </div>
            </div>

            <br>
            <div class="container">
                <h3 class="text-center col-white">FAQ For Home Loan</h3><br>
                <dl class="accordion">
                    <dt>When can you apply for a home loan?</dt>
                    <dd> 
                        <p>You can apply for a home loan when you are planning to buy a house. You can also apply when you are in the process of shortlisting properties.</p>
                    </dd>

                    <dt>What are the eligibility condition for a home loan?</dt>
                    <dd>
                        <p>The eligibility condition for a home loan is depicted below:</p>
                        <ul>
                         <li> An Indian Resident or NRI</li>
                         <li> Either self-employed or salaried</li>
                         <li> Above 21 years of age at the commencement of the loan.</li>
                         <li> Below 65 years when the loan matures.</li>
                        </ul>
                    </dd>

                    <dt>What are the securities/ collaterals you need to provide?</dt>
                    <dd>
                        <p>Immovable property owned by the applicants. The applicant's title to the property should be clear, marketable and free from any encumbrances. The security created on property shall be first and exclusive. Such security will be created by deposit of original title documents of the said property.</p>
                    </dd>
                    
                    <dt>What are the Tax Benefits of home loans?</dt>
                    <dd>
                        <p>Resident Indians are eligible for certain tax benefits on principal and interest components of a home loan. As per Income Tax Act 1961 rules, the current applicable exemption under section 24(b) is ` 2,00,000/- for the interest amount paid in the financial year and up to ` 1,50,000/- (under section 80 C) for the principal amount repaid in the same year.</p>
                    </dd>
                    
                    <dt>What are the interest rates offered for home loans?</dt>
                    <dd>
                        <p>Interest rate varies as per the market conditions whereas interest rates are dynamic in nature. The interest on home loans in India is usually calculated either on yearly reducing basis, daily reducing basis or monthly reducing basis.</p>
                    </dd>
                    
                    <dt>What is fixed rate of interest and floating rate of interest?</dt>
                    <dd>
                        <p>Fixed rate of interest refers to the rate of interest that remains unchanged for the entire duration of the loan. On the other hand, floating rate of interest refers to the rate of interest that fluctuates based on the market lending rate.</p>
                    </dd>
                    
                    <dt>Who can be the co-applicants for the loan?</dt>
                    <dd>
                        <p>Your Life Partner (Spouse) <br>Co-owner has to be necessarily co-applicant in the loan. <br>Any of your blood relative (immediate family members</p>
                    </dd>
                    
                    <dt>What is an amortization schedule?</dt>
                    <dd>
                        <p>An amortization schedule is a table that gives the reduction of your loan amount by monthly installments. It offers you the break-up of every EMI towards outstanding principal of your loan and the repayment interest of your loan.</p>
                    </dd>
                    
                    <dt>Are Securities required for home loans?</dt>
                    <dd>
                        <p>Many institutions ask for additional security such as FD receipts, saving certificates, shares and insurance policies. Whereas some consider the property to be purchased as security and is mortgaged to the institution till the entire loan is repaid. We ask for securities depending on the cases we receive.</p>
                    </dd>
                    
                    <dt>What is an EMI?  What is Pre-EMI Interest?</dt>
                    <dd>
                        <p>You repay the loan in Equated Monthly Installments (EMIs) comprising principal and interest.<br>
                        The interest that is charged on partially disbursed loan amount is Pre-EMI interest. And, that partially disbursed loan amount before the start of actual EMI is called Pre-EMI. Usually, this occurs at the construction stage linked disbursals.</p>
                    </dd>
                    
                    <dt>What are the other costs that come with home loans?</dt>
                    <dd>
                        <p>Below depicted are some of the costs that follows home loans: <br>
				1) Processing fee is payable on applying for a home loan <br>
				2) Other miscellaneous costs (like stamp paper etc.) for standard documentation charges</p>
                    </dd>
                    
                    <dt>What are the repayment period options?</dt>
                    <dd>
                        <p>Repayment period usually ranges between 5 to 35 years.</p>
                    </dd>
                </dl>
            </div>
            
            
        <br>
        </div>
        <!-- footer starts here -->
            <?php include('footer.php');?>
        
        <script src="js/whizz.js"></script>
        <script>
          (function( $ ) {
	$.fn.SimpleAccordion = function () {
		// Cache element
		var accordion = $(this);
		// Fade in on load
		accordion.hide().fadeIn();
		// Open active panel
		accordion.find(".active").show();
		// Listen to onClick
		accordion.find("dt").on("click", function (){
			// Cache current
			var current = $(this).next("dd");
			// Check if not active
			if (current.is(":hidden")) {
				// Open curren panel
				current.slideDown().siblings("dd").slideUp();
			}
		});
	};
})( jQuery );

$(".accordion").SimpleAccordion();
function getoccupation(occupation){
                if(occupation=='Salaried'){
                    $('#onchangedata1').hide();
                    $('#onchangedata').show();
                }
                if(occupation=='Self Employed (Business)'){
                    $('#onchangedata1').show();
                    $('#onchangedata').hide();
                }
                if(occupation=='Self Employed (Professional)'){
                    $('#onchangedata1').show();
                    $('#onchangedata').hide();
                } 
                if(occupation==''){
                    $('#onchangedata1').hide();
                    $('#onchangedata').hide();
                }
                if(occupation=='Retired'){
                    $('#onchangedata1').hide();
                    $('#onchangedata').hide();
                }
                if(occupation=='House Wife'){
                    $('#onchangedata1').hide();
                    $('#onchangedata').hide();
                }
               
            }
</script>
        
    </body>
</html>
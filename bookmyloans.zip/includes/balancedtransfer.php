<?php
require_once("init.php");
class BalanceTranfer
{
	protected static $table_name="balancetransfer";
	// for small tables this can be hard coded in the class file else for big tables we can create this by fireing a query to the databae
	// "select columns from table name" and construct this array dynamically
	protected static $db_fields = array('bt_id','full_name','email_id','mobile','dob','gender','purpose','occupation','copany_name','salary_received','since_bussiness','it_return','turnover','residency_location','loan_amount','monthly_income','co_applicant','property_value','property_name','existingbank','created_at','updated_at','active_status');

	public $bt_id;
	public $full_name;
	public $email_id;
	public $mobile;
	public $dob;
    public $gender;
    public $purpose;
    public $occupation;
    public $copany_name;
    public $salary_received;
    public $since_bussiness;
    public $it_return;
    public $turnover;
    public $residency_location;
    public $loan_amount;
    public $monthly_income;
    public $co_applicant;
    public $property_value;
    public $property_name;
    public $existingbank;
    public $created_at;
    public $updated_at;
	public $active_status;


	public static function find_by_full_name($full_name='')
	{
		global $database;
		$result=self::find_by_sql("select * from " . self::$table_name . " where ". self::$db_fields[1] . "='{$full_name}'");
		return $result;
	}
	
	public static function find_by_name($name='')
	{
		global $database;
		$result_array=self::find_by_sql("select * from " . self::$table_name . " where ". self::$db_fields[1] . "='{$name}' limit 1");
		return !empty($result_array) ? array_shift($result_array) : false;
	}
	
	public static function find_all_name_asc()
	{
		global $database;
		$result = self::find_by_sql("select * from " . self::$table_name." order by ". self::$db_fields[1] ." asc" );
		return $result;
	}

	public static function find_limit_8()
	{
		global $database;
		$result = self::find_by_sql("select * from " . self::$table_name." order by ". self::$db_fields[0] ." desc limit 8" );
		return $result;
	}
	
	public static function find_all()
	{
		global $database;
		$result = self::find_by_sql("select * from " . self::$table_name." order by ". self::$db_fields[0] ." desc" );
		return $result;
	}
	
	public static function find_next_code()
	{
		global $database;
		$result_array=self::find_by_sql("select * from " . self::$table_name." order by ". self::$db_fields[0] ." desc limit 1" );
		return !empty($result_array) ? array_shift($result_array) : false;
	}

	public static function find_by_code($bt_id=0)
	{
		global $database;
		$result_array=self::find_by_sql("select * from " . self::$table_name . " where ". self::$db_fields[0] . "='{$bt_id}' limit 1");
		return !empty($result_array) ? array_shift($result_array) : false;
	}
	
	public static function find_by_sql($sql="")
	{
		global $database;
		$result = $database->query($sql);
		$object_array=array();
		while($row = $database->fetch_array($result))
		{
			$object_array[]=self::instantiate($row);
		}
		
		return $object_array;
	}

	private static function instantiate($record)
	{
		$object = new self;	
		foreach($record as $attribute=>$value)
		{
			if($object->has_attribute($attribute))
			{
				$object->$attribute=$value;
			}
		}
		
		
		return $object;
	}
	
	private function has_attribute($attribute)
	{
		$object_vars=$this->attributes();
		return array_key_exists($attribute,$object_vars);
	}
	
	protected function attributes()
	{
		//returns an array of attributes with keys an their values
		//retrun get_object_vars($this);
		
		$attributes = array();
		foreach(self::$db_fields as $field)
		{
			if(property_exists($this,$field))
			{
				$attributes[$field] = $this->$field; // here $field is a dynamic variable that takes the value of the current variable as name of other one.
			}
		}
		return $attributes;
	}
	
	protected function sanitized_attributes()
	{
		global $database;
		$clean_attributes = array();
		// clean the values before submitting to the database object
		foreach($this->attributes() as $key=>$value)
		{
			$clean_attributes[$key] = $database->escape_value($value);
		}
		return $clean_attributes;
	}
	
	public function save()
	{
		// A new record wont have an id yet .. ;) 
		return $this->create();
	}
	
	protected function create()
	{
		global $database;
		
		$attribute = $this->sanitized_attributes();
		$sql = "Insert into " . self::$table_name . " (";
		$sql.= join(", ", array_keys($attribute));
		$sql.= ") values('";
		$sql.= join("', '", array_values($attribute));
		$sql.= "')";
		if($database->query($sql))
		{
			$this->bt_id=$database->insert_id();
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public function update()
	{
		global $database;
		
		$attributes = $this->sanitized_attributes();
		$attribute_pair = array();
		foreach($attributes as $key => $value)
		{
			$attribute_pair[] = "{$key}='{$value}'";
		}
		$sql = "Update " . self::$table_name . " set ";
		$sql.= join(", ",$attribute_pair);
		$sql.= " where bt_id='" . $database->escape_value($this->bt_id)."'";
		$database->query($sql);
		if($database->affected_rows()==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public function does_exist()
	{
		global $database;
		
		$attributes = $this->sanitized_attributes();
		$attribute_pair = array();
		foreach($attributes as $key => $value)
		{
			$attribute_pair[] = "{$key}='{$value}'";
		}
		$sql = "Select * from  " . self::$table_name . " where ";
		$sql.= join(" and ",$attribute_pair);
		$result_array=self::find_by_sql($sql);
		return !empty($result_array) ? array_shift($result_array) : false;
	}
	
	public function delete()
	{
		global $database;
		
		$sql ="Delete from " . self::$table_name ;
		$sql.=" where bt_id=" . $database->escape_value($this->bt_id);
		$sql.=" LIMIT 1";
		
		$database->query($sql);
		return ($database->affected_rows()==1) ? true : false ;
	}
	
}
?>
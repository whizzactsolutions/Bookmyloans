<?php

class MySQLDatabase
{
	private $connection;
	private $last_query;
	private $magic_quotes_active;
	private $real_escape_string_exists;
	function __construct()
	{
		$this->open_connection();
		$this->magic_quotes_active=get_magic_quotes_gpc();
		$this->mysql_real_escape_string = function_exists("mysql_real_escape_string");//i.e. php >= 4.3.0
	}

	public function open_connection()
	{
		@$this->connection = mysql_connect(DB_SERVER,DB_USER,DB_PASS);
		//$this->connection = mysql_connect('localhost', 'root', '');
		if(!isset($this->connection))
		{
			die("Database Connection Failed : " . mysql_error());
		}
		else
		{
			$db_select=mysql_select_db(DB_NAME,$this->connection);
			//$db_select=mysql_select_db('tsm',$this->connection);
			if(!isset($db_select))
			{
				die("Database Selection Failed : " . mysql_error());
			}
		}
	}

	public function close_connection()
	{
		if(isset($this->connection))
		{
			mysql_close($this->connection);
		}
		unset($this->connection);
	}

	public function query($sql)
	{
		$this->last_query=$sql;
		$result=mysql_query($sql,$this->connection);
		$this->confirm_query($result);
		return $result;
	}
	
	public function escape_value($value)
	{
		if($this->mysql_real_escape_string )
		{
			//undo any magic quote effects so mysql_real_escape_string can do the work
			if($this->magic_quotes_active){$value=stripslashes($value);}
			$value=mysql_real_escape_string($value);
		}
		else
		{// before php 4.3.0
			//if magic quote aren't already on then add slashes  manually
			if(!$this->magic_quotes_active){$value=addslashes($value);}
			//if magic quotes are active, then the slashes already exists
		}
		return $value;
	}
	
	public function fetch_array($resultset)
	{
		return mysql_fetch_array($resultset);
	}
	
	public function num_rows($resultset)
	{
		return mysql_num_rows($resultset);
	}
	
	public function insert_id()
	{
		//get the last id inserted over the current db connection
		return mysql_insert_id($this->connection);
	}
	
	public function affected_rows()
	{
		return mysql_affected_rows($this->connection);
	}
	
	private function confirm_query($result_set)
	{
		if(!$result_set)
		{
			$output="Database Query Failed : " . mysql_error() . "<br/><br/>";
			$output .= "Last SQL Query : " . $this->last_query;
			die($output);
		}
	}
}

//Just need to change this statement once you decide to change the Database 
$database = new MySQLDatabase();
$db =& $database;

?>
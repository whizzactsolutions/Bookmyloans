<?php

class MySQLDatabase
{
	private $connection;
	private $last_query;
	private $magic_quotes_active;
	private $real_escape_string_exists;
	function __construct()
	{
		$this->open_connection();
		$this->magic_quotes_active=get_magic_quotes_gpc();
		$this->mysqli_real_escape_string = function_exists("mysqli_real_escape_string");//i.e. php >= 7.0
	}

	public function open_connection()
	{
		//echo 'Durgesh';
		@$this->connection = mysqli_connect(DB_SERVER,DB_USER,DB_PASS);
		//$this->connection = mysqli_connect('localhost', 'root', '');
		//echo 'Ajinkya';

		if(!isset($this->connection))
		{
			die("Database Connection Failed : " . mysqli_error());
		}
		else
		{
			$db_select=mysqli_select_db($this->connection,DB_NAME);
			//$db_select=mysqli_select_db('tsm',$this->connection);
			if(!isset($db_select))
			{
				die("Database Selection Failed : " . mysqli_error());
			}
		}
	}

	public function close_connection()
	{
		if(isset($this->connection))
		{
			mysqli_close($this->connection);
		}
		unset($this->connection);
	}

	public function query($sql)
	{
		$this->last_query=$sql;
		$result=mysqli_query($this->connection,$sql);
		$this->confirm_query($result);
		return $result;
	}
	
	public function escape_value($value)
	{
		if($this->mysqli_real_escape_string )
		{
			//undo any magic quote effects so mysql_real_escape_string can do the work
			if($this->magic_quotes_active)
			{
				$value=stripslashes($value);
			}
			$value=mysqli_real_escape_string($this->connection,$value);
		}
		else
		{// before php 4.3.0
			//if magic quote aren't already on then add slashes  manually
			if(!$this->magic_quotes_active){$value=addslashes($value);}
			//if magic quotes are active, then the slashes already exists
		}
		return $value;
	}
	
	public function fetch_array($resultset)
	{
		return mysqli_fetch_array($resultset);
	}
	
	public function num_rows($resultset)
	{
		return mysqli_num_rows($resultset);
	}
	
	public function insert_id()
	{
		//get the last id inserted over the current db connection
		return mysqli_insert_id($this->connection);
	}
	
	public function affected_rows()
	{
		return mysqli_affected_rows($this->connection);
	}
	
	private function confirm_query($result_set)
	{
		if(!$result_set)
		{
			$output="Database Query Failed : " . mysqli_error($this->connection) . "<br/><br/>";
			$output .= "Last SQL Query : " . $this->last_query;
			die($output);
		}
	}
}

//Just need to change this statement once you decide to change the Database 
$database = new MySQLDatabase();
$db =& $database;

?>
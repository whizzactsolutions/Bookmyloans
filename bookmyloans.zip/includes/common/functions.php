<?php

function strip_zeros_from_date($marked_string="")
{
	//first remove the marked zeros
	$no_zeros=str_replace('*0','',$marked_string);
	//then remove any remaining marks
	$cleaned_string =  str_replace('*','',$no_zeros);
	return $cleaned_string;
}

function redirect_to($location = NULL)
{
	if($location!=NULL)
	{
		header("Location: {$location}");
		exit;
	}
}

function output_message($message="")
{
	if(!empty($message))
	{
		return "<p class=\"message\">{$message}</p>";
	}
	else
	{
		return "";
	}
}

function __autoload($class_name)
{
	$class_name=strtolower($class_name);
	$path=LIB_PATH.DS."{$class_name}.php";
	if(file_exists($path))
	{
		require_once($path);
	}
	else
	{
		die("The file {$class_name}.php could not be found by autoload");
	}
}

function include_layout_template($template_file="")
{
	include(TEMPLATE.DS.$template_file);
}

function wordFilter($text)
{
	$filter_terms = array('\bass(es|hole?)?\b', '\bpussy\b','\bcock\b','\bboob(s?)?\b',
	'\bshit(e|ted|ting|ty|head?)?\b','\bfuck(er|off|you| off?)?\b',
	'\bmotherfuc(ker|kers|kkers|kker)\b','\bchut(iya|iyaa|mari|marike?)?\b',
	'\bmaderchod\b','\bbhenchod\b','\bbhosdike\b','\bbhosda\b','\bbhosdi(wale|wala?)?\b',
	'\bpussy\b','\bcock\b','\blund\b','\bjhat(a|u|oo?)?\b','\bla(uda|wda|vda)\b',
	'\bgand(u|oo?)?\b','\bchod(u|oo?)?\b','\bjha(wada|vada|wadya|vadya)\b');
	$filtered_text = $text;
	foreach($filter_terms as $word)
	{
		$match_count = preg_match_all('/' . $word . '/i', $text, $matches);
		for($i = 0; $i < $match_count; $i++)
		{
			$bwstr = trim($matches[0][$i]);
			$filtered_text = preg_replace('/\b' . $bwstr . '\b/',
			str_repeat("*", strlen($bwstr)), $filtered_text);
		}
	}
	return $filtered_text;
}

?>
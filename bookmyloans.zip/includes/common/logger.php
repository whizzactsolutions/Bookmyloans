<?php
//require_once('../init.php');

class Logger
{
// make sure the log folder exisits and webserver have the rights to r/w to this folder and the files in it.
	public static function log_action($action, $message="")
	{
		//convert the 
		$fname=strftime("%Y%m%d",time());
		$logfile=LOG_PATH.DS.$fname.'.log';
		$new=file_exists($logfile)?false:true;
		if($handle=fopen($logfile,'a'))
		{
			$timestamp=strftime("%Y-%m-%d %H:%M:%S", time());
			$content="{$timestamp} | {$action} : {$message}\n";
			fwrite($handle,$content);
			fclose($handle);
			// this is to make sure that the file is only writeable to the webserver
			if($new) 
			{
				chmod($logfile,0755);
			}
		}
		else
		{
			output_message("Could not open log file for writing ");
		}
	}

	public static function read_log_file($log_filename)
	{
		//convert the 
		if(file_exists($log_filename) && is_readable($log_filename) && $handle=fopen($log_filename,'r'))
		{
			echo "<ul class=\"log_entries\">";
			while(!feof($handle))
			{
				$entry=fgets($handle);
				if(trim($entry)!="")
				{
					echo "<li>{$entry}</li>";
				}
			}
			echo "</ul>";
			fclose($handle);
		}
		else
		{
			echo "Could not read from {$log_filename}";
		}
	}
	
	public static function clear_logs($log_filename)
	{
		file_put_contents($log_filename,'');
		self::log_action("Log Cleared","User cleared a log now");
	}
	
	public static function show_all_logs()
	{
		// read all the files from the log directory and show it in the ul and li tag ..
	}
}
?>
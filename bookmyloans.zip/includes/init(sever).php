<?php
//Define the core path
//Define them as absolute paths to make sure that require_once works as expected

//DIRECTORY_SEPERATOR is a PHP pre-defined constant
//(\ for windows, / or unix)

//defined('DS') ? null : define('DS',DIRECTORY_SEPARATOR);

defined('DS') ? null : define('DS','/');

// Define the Site root Configuration

defined('SITE_ROOT')? null : define('SITE_ROOT',DS.'home'.DS.'labtes');

// Define the include directory path that has all the class files
defined('LIB_PATH')?null:define('LIB_PATH',SITE_ROOT.DS.'public_html'.DS.'includes');

// Define the path for the Log directory on the web server
defined('LOG_PATH')?null:define('LOG_PATH',SITE_ROOT.DS.'public_html'.DS.'logs');

// Define the path for the design template directory
defined('TEMPLATE')?null:define('TEMPLATE',SITE_ROOT.DS.'public_html'.DS.'layouts');

//Load the config file first
require_once(LIB_PATH.DS.'common'.DS.'config.php');

//Load basic functions next so that everything after can use them
require_once(LIB_PATH.DS.'common'.DS.'functions.php');

//Load Database class and the global Object
require_once(LIB_PATH.DS.'common'.DS.'database.php');

//Load Logger Class
require_once(LIB_PATH.DS.'common'.DS.'logger.php');

require_once(LIB_PATH.DS.'admindetail.php');

require_once(LIB_PATH.DS.'enquirydetail.php');

require_once(LIB_PATH.DS.'gallerydetail.php');

require_once(LIB_PATH.DS.'productdetail.php');

require_once(LIB_PATH.DS.'quotedetail.php');

require_once(LIB_PATH.DS.'videodetail.php');

require_once(LIB_PATH.DS.'categorydetail.php');

require_once(LIB_PATH.DS.'maincategorydetail.php');

require_once(LIB_PATH.DS.'quotation_price.php');

require_once(LIB_PATH.DS.'quotationdetail.php');

require_once(LIB_PATH.DS.'quoteproductdetail.php');

?>
<html>
<head>
        <title>Bookmyloans - Mumbai's no 1 loans market place.</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<?php include('topheader.php');?>
		
        <style>
           .con2 /*background image css don't move this css*/
            {
                background-image: url(images/bgimage.jpg);
                background-size: cover;
                background-repeat: no-repeat;
                height: auto;
                margin-top: 52.4px;
            }
           
        </style>
</head>
<body>
    
    <?php include("newvisitor.php");?>
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- Navigation Code starts here -->
			<?php include('navigation.php');?>
        <!-- Navigation Code ends here -->  
<!-- ------------------------------------------------------------------------------------------ -->
<?php include('loan-calculator.php'); ?>
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- Content 2 after the navigation starts here -->
        <div class="container-fluid con2">
            <div class="row">
                <!-- content 1 left side starts here-->
                <div class="col-sm-5">
                    <br>
                    <div style="width: 100%; padding-top: 1%; border: 2px solid #f1c40f;border-radius: 10px; " class="center-block">
                        <center>
                            <h2 class="col-white font-key">Apply Your Loans</h2>
                        </center>
                        <form style="padding-left:2%; padding-right:10%;" action="control/getloansfile.php" method="POST">
                       <!-- <div class="row" style="padding-left: 2%; padding-right: 2%;">
                            <div class="col-sm-4 col-xs-4">
                                <div class="radio">
                                  <label class="col-white"><input type="radio" name="optradio" value="Home Loan">Home Loan</label>
                                </div>
                            </div>
                            <div class="col-sm-4 col-xs-4">
                                <div class="radio">
                                  <label class="col-white"><input type="radio" name="optradio" value="Balance Transfer">Balnce Tranfer</label>
                                </div>
                            </div>
                            <div class="col-sm-4 col-xs-4">
                                <div class="radio">
                                  <label class="col-white"><input type="radio" name="optradio" value="Mortgage Loan">Mortgages Loan </label>
                                </div>
                            </div> 
                            <div class="col-sm-6 col-xs-6">
                                <div class="radio">
                                  <label class="col-white"><input type="radio" name="optradio" value="Personal Loan">Personal Loan</label>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-6">
                                <div class="radio" style="float:right;padding-right:30px;">
                                  <label class="col-white"><input type="radio" name="optradio" value="Business Loan">Business Loan </label>
                                </div>
                            </div>
                        </div>-->
                        <br>                        
                            <div class="row">
                                <div class="col-sm-10">
                                    <div class="form-group">
                                      
                                      <select class="form-control border_radius_none" name="optradio" id="optradio" required>
                                        <option>Select Loans</option>
                                        <option value="Home Loan">Home Loan</option>
                                        <option value="Balance Transfer">Balnce Tranfer</option>
                                        <option value="Mortgage Loan">Mortgages Loan</option>
                                        <option value="Personal Loan">Personal Loan</option>
                                        <option value="Business Loan">Business Loan </option>
                                      </select>
                                    </div>
                                </div>
                                <br><br>

                                <div class="col-sm-10">
                                    <div class="group"> 
                                      <input type="number" id="amount" name="amount" pattern="[0-9]{5}" minlength="5" class="input" required style="width:110%;height:6%" title="pls enter valid amount" onkeyup="getloanamount(this.value)"><span style="color:red;" id="loanamountmsg"></span>
                                      <span class="highlight"></span>
                                      <span class="bar"></span>
                                      <label class="label" style="color:black;">Enter Loan  Amount</label>
                                    </div>
                                </div>
                                
                                <div class="col-sm-10">
                                    <div class="group">      
                                      <input type="text" name="fname" class="input" required style="width:110%;height:6%" title="pls enter valid name">
                                      <span class="highlight" style="width:200px;"></span>
                                      <span class="bar"></span>
                                      <label class="label" style="color:black;">Enter Your Name</label>
                                    </div>
                                </div>
                                 
                                 <div class="col-sm-10">
                                    <div class="group">      
                                      <input type="email" name="email_id" class="input" required style="width:110%;height:6%">
                                      <span class="highlight"></span>
                                      <span class="bar"></span>
                                      <label class="label" style="color:black;">Enter Your Email-ID</label>
                                    </div>
                                </div>
                                                               
                                <div class="col-sm-10">
                                    <div class="group">     
                                      <input type="text" id="mobile" name="mobile" class="input" required style="width:110%;height:6%;" pattern="[789][0-9]{9}" title="Pls enter valid and 10 digits mobile number" minlength="10" maxlength="10">
                                        <span id="mobileValidation" style="color:#ee5253;font-weight: bold;"></span> 
                                      <span class="highlight"></span>
                                      <span class="bar"></span>
                                      <label class="label" style="color:black;">Enter Your Mobile Number</label>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary center-block loan-elig" style="width: 30%;"><b>Process</b></button>
                        </form>
                    </div>
                </div>
                <!-- content 1 left side ends here-->
                
                <div class="col-sm-1"></div>
                <!-- content 2 right side starts here-->
                <div class="col-sm-6" data-aos="fade-left">
                    <div id="myCarousel" class="carousel slide" data-ride="carousel" style="margin-top: 15%;">
                      <!-- Wrapper for slides -->
                      <div class="carousel-inner">
                        <div class="item active">
                            <center>
                                <p class="col-site" style="font-size: 50px;color: #F5821F"><strong>HOME LOAN FROM</strong></p>
                                <p style="font-size: 85px;color:#fbc531;" class=""><b>8.45%*<sub>p.a.</sub></b></p>
                                <h3 class=" font-key" style="color:#fbc531;">Avail maximum subsidy benefit up to 2.67 Lakh*INR</h3>
                                <h3 class=" font-key" style="color:#fbc531;">UNDER PRADHAN MANTRI AWAS YOJANA</h3><br>
                                <h4 class="" style="font-size: 20px;color:#fbc531;">Enhance your loan amount by up to 20%<br>Enhanced eligibility for self-employed 30 year team 7 yeears <br>beyond retirment Five year extension for middle aged</h4>
                            </center>
                        </div>

                        <div class="item ">
                          <h1 class="col-site text-center" style="font-size: 40px;color: #F5821F"><strong>BUSINESS LOAN MADE EASY</strong></h1>  
                            <br>
                          <p class="font-key text-center col-white" style="font-size: 25px;color:#fbc531;">We've simplified the process. Apply<br>for our business loan in minutes,<br>without painful paperwork or<br>waiting in queues.</p>
                        </div>

                        <div class="item">
                          <h1 class="col-site text-center" style="font-size: 45px;color: #F5821F"><strong>PERSONAL LOAN</strong></h1>  
                            <br>
                          <p class="font-key text-center col-white" style="font-size: 25px;color:#fbc531;">Instant &amp; Affordable Personal Loans For Salaried &amp; Self-EmployedShop All You Want This Festive Season With Our Quick And Easy Personal Loan</p>
                        </div>
                          <div class="item">
                          <h1 class="col-site text-center" style="font-size: 45px;color: #F5821F"><strong>MORTGAGES LOAN</strong></h1>  
                            <br>
                          <p class="font-key text-center col-white" style="font-size: 25px;color:#fbc531;">Let your property be a shelter to your dreams. Loan Against Property is a multi-purpose loan that can be used for your business or personal needs</p>
                        </div>
                      </div>
                    </div>    
                </div>
                <!-- content 2 right side starts here-->
            </div>
            <br><br><br><br>
        
            <span id="loan"></span>
        </div>
        <!-- Content 2 after the navigation ends here -->
<!-- ------------------------------------------------------------------------------------------ -->        
        <!-- Content 3 after the navigation starts here TOL-->
        <div class="container">
            <h2 class="font-h">TYPES OF LOANS</h2>
            <h3 class="font-p text-muted">At Bookmyloan We Offer Quick Hassle-Free Loans For Several Purposes</h3>
            <br>
               <div class="row">
                   <div class="col-sm-6 bd-dk-fill shad">
                       <h3 class="col-white">
                           <img src="images/product-home.png" width="80" height="50" border="0">Home Loan
                       </h3> 
                       <p class="font-key f15 col-white">
                           The ownership of a house is one of the key signs of success among the fast-growing Indian middle class. As the income of the average Indian family increases, there has been a continuous increase in the desire to own a house and this has lead the price of property to reach unmatched highs in recent years.
                       </p>
            
                       <a href="home_loan.php"><button class="btn btn-primary btn-apply center-block">VIEW FEES</button></a>
                       <br><br>
                   </div>
		           <div class="col-sm-6 bd-dk-fill2 shad">
                        <h3 class="col-white">
                           <img src="images/personal_loan.png" width="60" height="50" border="0">&nbsp;&nbsp;Personal Loan
                       </h3> 
                       <p class="font-key f15 col-white">
                           A personal loan is a short to medium term unsecured loan (no collateral) that you can use to meet current financial needs. Though most commonly used to meet expenses related to debt restructuring, vacations, unexpected medical expenses and down payments.
                       </p>
                       <br>
                       <a href="personal_loan.php"><button class="btn btn-primary btn-apply1 center-block">VIEW FEES</button></a>
                       <br>
                   </div>
                   <div class="col-sm-6 bd-dk-fill1 shad">
                       <h3 class="col-white">
                           <img src="images/motrageg loan.jpg" width="60" height="50" border="0">&nbsp;&nbsp;Mortgages Loan
                       </h3> 
                       <p class="font-key f15 col-white ">
                           A mortgage loan, or simply mortgage, is used either by purchasers of real property to raise funds to buy real estate, or alternatively by existing property owners to raise funds for any purpose, while putting a lien on the property being mortgaged.
                       </p>
                       <br>
                       <a href="motrageage_loan.php"><button class="btn btn-primary btn-apply1 center-block">VIEW FEES</button></a>
                       <br>
                   </div>
                   <div class="col-sm-6 bd-dk-fill3 shad">
                       <h3 class="col-white">
                           <img src="images/Business loan.png" width="60" height="50" border="0">Business Loan
                       </h3> 
                       <p class="font-key f15 col-white ">
                           Businesses need ample amount of investment to fund for start-up expenditures or pay for business extensions. For such purposes, companies take out business loans for their financial assistance. It is a debt which a company is obligated to pay back within a specific tenure according to the terms and conditions of the granted loan.
                       </p>
                        <a href="business_loan.php"><button class="btn btn-primary btn-apply center-block">VIEW FEES</button></a>
                   </div>
		</div>

        </div>
        <!-- Content 3 after the navigation ends here -->
        <br><br>
        <hr>
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- Content 3 div's left start here -->
        <div class="container">
            <div class="row text-center">
              <div class="col-md-3 shad pad-top-bot">
                <span class="fa-stack fa-4x">
                 <img src="images/easy-application.png" width="100" height="100" border="0" alt="">
                </span>
                <h4 class="service-heading col-key">Easy application</h4>
                <p class="text-muted">Complete our online application. It's quick, easy, and confidential</p>
              </div>
              <div class="col-md-3 shad pad-top-bot">
                <span class="fa-stack fa-4x">
                 <img src="images/fast-detection.png" width="100" height="100" border="0" alt="">
                </span>
                <h4 class="service-heading col-key">Fast decision</h4>
                <p class="text-muted">If You're Pre-Approved, E-Sign your Application To Confirm Funds.</p>
              </div>
              <div class="col-md-3 shad pad-top-bot">
                <span class="fa-stack fa-4x">
                 <img src="images/getcasheasy.png" width="100" height="100" border="0" alt="">
                </span>
                <h4 class="service-heading col-key">Get Your Cash</h4>
                <p class="text-muted">Cash Deposited To Your Bank Account As Quickly As The Next Business Day.</p>
              </div>
              <div class="col-md-3 shad pad-top-bot">
                <span class="fa-stack fa-4x" style="color:#ff6600;">
                 <img src="images/repayloan.jpg" width="100" height="100" border="0" alt="">
                </span>
                <h4 class="service-heading col-key">Repay Your Loan</h4>
                <p class="text-muted">The Original Amount &amp; The Fees Will Be Debited From Your Bank Account.</p>
              </div>
            </div>	
            <span id="know_about"></span>
        </div>
        <hr>
        <!-- Content 3 div's left ends here -->        
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- Content 4 starts here -->        
        <div class="container-fluid" >
            <div class="row">
                <div class="col-sm-6" style="border-right: 1px solid #bdc3c7;">
                 <h2 style="color:#5A4678; font-weight: bolder;"><span style="border-bottom: 3px solid #f39c12;">Kno</span>w About Us </h2><br>
			         <p style="color:#330033;" class="font-key f15">Prior to Bookmyloans.com services, We have vast experience of more than 12 years in financial field with various Private Banks &amp; BFCs through DSA for Personal Loan, Business Loan, Home Loan, &amp; Mortgage Loan.</p>

			         <p class="font-key f15">Bookmyloans.com is a start-up which believes in its ability to create a perfect alliance of Personal Finance, Technology and Digital Content. At Bookmyloan, our endeavor is to make a difference in the lives of millions of people by changing the way they deal in matters related to Personal Finance by creating:

                     <p class="font-key f15">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1.<strong>Easy to consume digital content </strong>&amp;</p>
                     <p class="font-key f15">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.<strong>Simple to use technology driven tools</strong></p>

			         <p class="font-key f15">We believe that sound investment advice and cheap, easy loans should not be restricted to a privileged few. Our aim is combine content and technology effectively to be able to create an ecosystem where matters related to money do not make anyone uncertain and nervous.</p>


                     <p class="font-key f15">Bookmyloans.com is the digital offering of <strong>Aparna Distribute Private Limited (ADPL)</strong>. ADPL is a boutique financial advisory firm which specializes in Mortgages for <strong>High Networth Individuals </strong>(HNIs). In a short span of 5 years, <strong>ADPL </strong>facilitates mortgage transactions of over USD 30 million annually.</p>
			     </div>
                <div class="col-sm-6">
                    <h3><img src="images/splist1.png" style="height:10%;width:20%";> Dedicated Specialists</h3><br>
                    <p class="font-key f15">Prior to Bookmyloans.com services, We have vast experience of more than 12 years in financial field with various Private Banks &amp; BFCs through DSA for Personal Loan, Business Loan, Home Loan, &amp; Mortgage Loan.</p>
                    <h3><img src="images/success1.png" style="height:10%;width:20%";> Success Stories Rating</h3>
                    <p class="font-key f15">Here is what some of our happy customers tell about our services offered to the customer by Bookmyloan.com Loan</p>
                    <h3><img src="images/front%20apprial.png" style="height:10%;width:20%";> No front Appraisal Fees!</h3>
                    <p class="font-key f15">Appraisal fee, and/or an broker/commitment fee up front, which would not be taken for the assessment</p>
                </div>
            </div>
        </div>
        <hr>
        <!-- Content 4 ends here -->        
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- Content 5 starts here -->
        <div class="container">
            <h2 class="font-h">WHAT MAKES US SPECIAL?</h2>
            <div class="row text-center">
              <div class="col-sm-4 shad pad-top-bot">
                <span class="fa-stack fa-4x">
                 <img src="images/one_stop.jpg" width="100" height="100" border="0" alt="">
                </span>
                <h4 class="service-heading col-key">OneStop Shop</h4>
                <p class="text-muted">We have all your personal finance related needs covered</p>
              </div>
              <div class="col-sm-4 shad pad-top-bot">
                <span class="fa-stack fa-4x">
                 <img src="images/safe_secure.png" width="100" height="100" border="0" alt="">
                </span>
                <h4 class="service-heading col-key">Safe &amp; Secure</h4>
                <p class="text-muted">We take all the necessary measures to secure your personal data during transmission and storage</p>
              </div>
              <div class="col-sm-4 shad pad-top-bot">
                <span class="fa-stack fa-4x">
                 <img src="images/advice.png" width="100" height="100" border="0" alt="">
                </span>
                <h4 class="service-heading col-key">Personalized Advice</h4>
                <p class="text-muted">Plan your financial goals using personalized advice from our highly qualified team.</p>
              </div>
            </div>	
        </div> 
        <br>
        <!-- Content 5 ends here -->  
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- Content 6 starts here -->
        <div class="container-fluid" style="background-color: #F5F5F6; padding-top: 8%;padding-bottom:3%;">
            <div class="container">
            <div class="row">
                <div class="col-sm-3 mar-top">
                    <div style="background-color: white; padding: 5%;">
                       <div style="margin-top: -80px;">
                        <i class="fa fa-user fnt-cus"></i> 
                        <h1 class="text-center"><b>
                            <?php 
                            $hicount = Visitor::find_all_limit();
                            if($hicount){
                                foreach($hicount as $allcount){
                                    echo  $allcount->visitor_code; 
                                }
                            } 
                            ?>
                            </b></h1> 
                        <h4 class="text-center">BORROWERS</h4> 
                        <p class="f16 text-center font-key">Borrowers accounts accross our mobile and web apps</p> 
                       </div>
                    </div>
                </div>
                <div class="col-sm-3 mar-top">
                    <div style="background-color: white; padding: 5%;">
                       <div style="margin-top: -80px;">
                        <i class="fa fa-file-pdf-o fnt-cus"></i>
                        <h1 class="text-center"><b>850</b></h1> 
                        <h4 class="text-center">APPLICATIONS</h4> 
                        <p class="f16 text-center font-key">Loan Application Processed</p> 
                        <br>
                       </div>
                    </div>
                </div>
                <div class="col-sm-3 mar-top">
                    <div style="background-color: white; padding: 5%;">
                       <div style="margin-top: -80px;">
                        <i class="fa fa-rupee fnt-cus"></i> 
                        <h1 class="text-center"><b>132</b></h1> 
                        <h4 class="text-center">LAKH DISBURSED</h4> 
                        <p class="f16 text-center font-key">Loan Disbursed to Date</p> 
                        <br>
                       </div>
                    </div>
                </div>
                <div class="col-sm-3 mar-top">
                    <div style="background-color: white; padding: 5%;">
                       <div style="margin-top: -80px;">
                        <i class="fa fa-hospital-o fnt-cus"></i>
                        <h1 class="text-center"><b>6</b></h1> 
                        <h4 class="text-center">LENDERS</h4> 
                        <p class="f16 text-center font-key">Banks and NBFCs lending on our platform</p> 
                       </div>
                    </div>
                </div>
            </div>
            </div>
            <span id="contact"></span>
        </div>       
        <br>
        <!-- Content 6 ends here -->        
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- Content 6 starts here -->
        <div class="container">
            <h1 class="font-key text-center" style="color: #F5821F;">GET IN TOUCH</h1>
            <h4 class="font-key text-center">We Will Get Back To You As Soon As Possible</h4>
            <br><br>
            <div class="row">
                <div class="col-sm-5">
                    <div class="row">
                        <div class="col-sm-3">
                            <i class="fa fa-map-marker con-fon"></i>
                        </div>
                        <div class="col-sm-9">
                            <h4 class="font-key cen">MIDC Residential Area,<br> Mamta Hospital, <br>Dombivli(East) - 421203</h4>
                        </div>
                    </div><br><br>
                    <div class="row">
                        <div class="col-sm-3">
                            <i class="fa fa-mobile-phone con-fon"></i>
                        </div>
                        <div class="col-sm-9">
                            <h4 class="font-key cen"><a href="tel:+919137319582">(+91) 91373 19582</a> </h4>
                        </div>
                    </div><br><br>
                    <div class="row">
                        <div class="col-sm-3">
                            <i class="fa fa-envelope-o con-fon"></i>
                        </div>
                        <div class="col-sm-9">
                            <h4 class="font-key cen"><a href="mailto:enquiry@bookmyloans.co.in">enquiry@bookmyloans.co.in</a></h4>
                        </div>
                    </div>
                    
                </div><br>
                <div class="col-sm-1"></div>
                <div class="col-sm-6">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                              <input type="text" class="form-control feed-in" placeholder="First Name">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                              <input type="text" class="form-control feed-in" placeholder="Last Name">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                              <input type="text" class="form-control feed-in" placeholder="Email">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                              <input type="text" class="form-control feed-in" placeholder="Mobile Number">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                              <textarea class="form-control feed-in" rows="5" placeholder="Your Message..."></textarea>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="btn btn-primary pull-right" style="border-radius: 0; width: 20%;">Submit</button>
                </div>
            </div>
            <br>
        </div>
        <!-- Content 6 ends here -->
        <br>
<!-- ------------------------------------------------------------------------------------------ -->
    
        <!-- footer starts here -->
           <?php include('footer.php');?>
    </body>
</html>
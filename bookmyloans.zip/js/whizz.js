$('#email').first().keyup(function () {
    var $email = this.value;
    validateEmail($email);
});

function validateEmail(email) {
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    if (!emailReg.test(email)) {
        $('#emailValidation').html("<b>Pls enter valide email ID.</b>");
    } else {
        $('#emailValidation').html("");
    }
}

$('#mobile').on('keyup',function(event){
    var mobile = $('#mobile').val();
    var filter = /^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/;
 
    if(filter.test(mobile)){
        if(!$('#mobile').val().match('[0-9]{10}'))  {
            alert("Please put 10 digit mobile number");
        $('#mobileValidation').html("<b>Please enter valide mobile number</b>");
        return;
    }
    }
   /* if(!$('#mobile').val().match('[0-9]{10}'))  {
        $('#mobileValidation').html("<b>Please put 10 digit mobile number</b>");
        return;
    }else{
        $('#mobileValidation').html("");
        return;
    }*/
});
function getloanamount(loanamount){
    if(loanamount < 1000000){
        /*var len = this.value.length;
    if (len == 3 || len == 7 || len == 11) {
       $(this).val(this.value + "-");
    }

    else if (len == 15) {
      $(this).val(this.value + " ");  
    } */
        $('#loanamount').css("background-color","red");
        $('#loanamountmsg').html("Min loan amount 10,00,000");
    }else{
        $('#loanamountmsg').html('');
        $('#loanamount').css("background-color","#156DD1");
    }
}
function getmothlyincome(txtmonthlyincome){
    if(txtmonthlyincome < 25000){
        $('#monthlyincome').css("color","red");
        $('#monthlyincome').html("Min loan amount 25,000");
    }else{
        $('#monthlyincome').html('');
        $('#monthlyincome').css("background-color","#156DD1");
    }
}
/***********************************HOME LOAN**************************************************/
/********************************Property radio***********************************/            
$('input:radio[name="propertyradio"]').change(
    function(){
        if ($(this).is(':checked') && $(this).val() == 'Yes') {
            $('#propertydata').css('display','block');
        }
        if ($(this).is(':checked') && $(this).val() == 'No') {
            $('#propertydata').css('display','none');
        }
});
/*******************************co applicant**********************************/
$('input:radio[name="coapplicant1"]').change(
    function(){
        if ($(this).is(':checked') && $(this).val() == 'Yes') {
            $('#coapplicantid').css('display','block');
        }
        if ($(this).is(':checked') && $(this).val() == 'No') {
            $('#coapplicantid').css('display','none');
        }
});
/************************************HOME LOAN**********************************************/ 
function gethomeloan(){
    var full_name = $('#full_name').val();
    var email_id = $('#email_id').val();
    var mobile = $('#mobile').val();
    var txtdob = $('#txtdob').val();
    var optradio = $('#gender').val();
    var purpose = $('#purpose').val();
    var occupation = $('#occupation').val();
    var residency_location = $('#residency_location').val();
    var loanamount = $('#loanamount').val();
    var txtmonthlyincome = $('#txtmonthlyincome').val();
    var coapplicant1 = $('#coapplicant').val();
    var coapp_income = $('#coapp_income').val();
    var propertyradio = $('#propertyradio').val();
    var propert_location = $('#propert_location').val();
    var property_value = $('#property_value').val();
    var property_name = $('#property_name').val();
    var copany_name = $('#company_name').val();
    var salary_received = $('#salary_recived').val();
    var since_bussiness = $('#inbusinesssince').val();
    var it_return = $('#itreturnfile').val();
    var turnover = $('#annualturnover').val();

    
    $("#popupdiv").show();
    $.post('sms/homeloansendsms.php',{full_name:full_name,email_id:email_id,mobile:mobile,txtdob:txtdob,optradio:optradio,purpose:purpose,occupation:occupation,residency_location:residency_location,loanamount:loanamount,txtmonthlyincome:txtmonthlyincome,coapplicant1:coapplicant1,coapp_income:coapp_income,propertyradio:propertyradio,propert_location:propert_location,property_value:property_value,property_name:property_name,copany_name:copany_name,salary_received:salary_received,since_bussiness:since_bussiness,it_return:it_return,turnover:turnover},
    function(markup){

        $('#popup-main-content').html("");
        $('#popup-main-content').html(markup);
    });	
}
function gethomeloans(){
    var full_name = $('#full_name').val();
    var email_id = $('#email_id').val();
    var mobile = $('#mobile').val();
    var txtdob = $('#txtdob').val();
    var optradio = $('#gender').val();
    var purpose = $('#purpose').val();
    var occupation = $('#occupation').val();
    var residency_location = $('#residency_location').val();
    var loanamount = $('#loanamount').val();
    var txtmonthlyincome = $('#txtmonthlyincome').val();
    var coapplicant1 = $('#coapplicant').val();
    var coapp_income = $('#coapp_income').val();
    var propertyradio = $('#propertyradio').val();
    var propert_location = $('#propert_location').val();
    var property_value = $('#property_value').val();
    var property_name = $('#property_name').val();
    var copany_name = $('#company_name').val();
    var salary_received = $('#salary_recived').val();
    var since_bussiness = $('#inbusinesssince').val();
    var it_return = $('#itreturnfile').val();
    var turnover = $('#annualturnover').val();

    var otpnumber = $('#otpnumber').val();
    var cotp = $('#cotp').val();
    
    if(cotp==otpnumber){
    $.post('control/homeloan_control.php?mode=i',{full_name:full_name,email_id:email_id,mobile:mobile,txtdob:txtdob,optradio:optradio,purpose:purpose,occupation:occupation,residency_location:residency_location,loanamount:loanamount,txtmonthlyincome:txtmonthlyincome,coapplicant1:coapplicant1,coapp_income:coapp_income,propertyradio:propertyradio,propert_location:propert_location,property_value:property_value,property_name:property_name,copany_name:copany_name,salary_received:salary_received,since_bussiness:since_bussiness,it_return:it_return,turnover:turnover},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
        window.location.href="index.php";
	});
    }
    else{
        alert("Please enter valid OTP");
    }
}
/************************************END HOME LOAN**********************************************/ 
/************************************BALANCE TRANSFER**********************************************/
function getbalancetransfer(){
    var full_name = $('#full_name').val();
    var email_id = $('#email_id').val();
    var mobile = $('#mobile').val();
    var txtdob = $('#txtdob').val();
    var optradio = $('#gender').val();
    var purpose = $('#purpose').val();
    var occupation = $('#occupation').val();
    var residency_location = $('#residency_location').val();
    var loanamount = $('#loanamount').val();
    var txtmonthlyincome = $('#txtmonthlyincome').val();
    var coapplicant1 = $('#coapplicant').val();
    var coapp_income = $('#coapp_income').val();
    var property_value = $('#property_value').val();
    var copany_name = $('#company_name').val();
    var salary_received = $('#salary_recived').val();
    var since_bussiness = $('#inbusinesssince').val();
    var it_return = $('#itreturnfile').val();
    var turnover = $('#annualturnover').val();
    var existingbank = $('#existingbank').val();

    var property_name = $('#property_name').val();
    
    $("#popupdiv").show();
    
    $.post('sms/balancetransfersendsms.php',{full_name:full_name,email_id:email_id,mobile:mobile,txtdob:txtdob,optradio:optradio,purpose:purpose,occupation:occupation,residency_location:residency_location,loanamount:loanamount,txtmonthlyincome:txtmonthlyincome,coapplicant1:coapplicant1,coapp_income:coapp_income,property_value:property_value,property_name:property_name,copany_name:copany_name,salary_received:salary_received,since_bussiness:since_bussiness,it_return:it_return,turnover:turnover,existingbank:existingbank},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});	
}
function getbalancetransfers(){
    var full_name = $('#full_name').val();
    var email_id = $('#email_id').val();
    var mobile = $('#mobile').val();
    var txtdob = $('#txtdob').val();
    var optradio = $('#gender').val();
    var purpose = $('#purpose').val();
    var occupation = $('#occupation').val();
    var residency_location = $('#residency_location').val();
    var loanamount = $('#loanamount').val();
    var txtmonthlyincome = $('#txtmonthlyincome').val();
    var coapplicant1 = $('#coapplicant').val();
    var coapp_income = $('#coapp_income').val();
    var property_value = $('#property_value').val();
    var property_name = $('#property_name').val();
    var copany_name = $('#company_name').val();
    var salary_received = $('#salary_recived').val();
    var since_bussiness = $('#inbusinesssince').val();
    var it_return = $('#itreturnfile').val();
    var turnover = $('#annualturnover').val();
    var existingbank = $('#existingbank').val();

    var otpnumber = $('#otpnumber').val();
    var cotp = $('#cotp').val();
    if(cotp==otpnumber){    
    $.post('control/balancetransfer_control.php?mode=i',{full_name:full_name,email_id:email_id,mobile:mobile,txtdob:txtdob,optradio:optradio,purpose:purpose,occupation:occupation,residency_location:residency_location,loanamount:loanamount,txtmonthlyincome:txtmonthlyincome,coapplicant1:coapplicant1,coapp_income:coapp_income,property_value:property_value,property_name:property_name,copany_name:copany_name,salary_received:salary_received,since_bussiness:since_bussiness,it_return:it_return,turnover:turnover,existingbank:existingbank},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
        window.location.href="index.php";
	});	
    }else{
        alert("Please enter valid OTP.");
    }
}
/************************************END BALANCE TRANSFER**********************************************/ 
/**************************************Motrageage Loan**********************************************/
function getmotrageage(){
    
    var full_name = $('#fname').val();
    var email_id = $('#email').val();
    var mobile = $('#mobile').val();
    var dob = $('#txtdob').val();
    var gender = $('#gender').val();
    var loan_amount = $('#loanamount').val();
    var monthly_income = $('#txtmonthlyincome').val();
    var occupation = $('#occupation').val();
    var property_value = $('#property_value').val();
    var residency_location = $('#residency_location').val();
    
    $("#popupdiv").show();
     $.post('sms/motrageagesendsms.php',{full_name:full_name,email_id:email_id,mobile:mobile,dob:dob,gender:gender,residency_location:residency_location,loan_amount:loan_amount,monthly_income:monthly_income,occupation:occupation,property_value:property_value},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});
    
}
function getmotrageages(){
    
    var full_name = $('#fname').val();
    var email_id = $('#email').val();
    var mobile = $('#mobile').val();
    var dob = $('#txtdob').val();
    var gender = $('#gender').val();
    var loan_amount = $('#loanamount').val();
    var monthly_income = $('#txtmonthlyincome').val();
    var property_value = $('#property_value').val();
    var occupation = $('#occupation').val();
    var residency_location = $('#residency_location').val();
    var otpnumber = $('#otpnumber').val();
    var cotp = $('#cotp').val();
    if(cotp==otpnumber){    
    
         $.post('control/motrageage_control.php?mode=i',{full_name:full_name,email_id:email_id,mobile:mobile,dob:dob,gender:gender,residency_location:residency_location,loan_amount:loan_amount,monthly_income:monthly_income,occupation:occupation,property_value:property_value},
        function(markup){

            $('#popup-main-content').html("");
            $('#popup-main-content').html(markup);
            window.location.href="index.php";
        });	
    }else{
        alert("Please enter valid OTP.");
    }
}
/**************************************End Motrageage Loan**********************************************/
/**************************************Personal Loan**********************************************/
function getPersonal(){
   // alert();
    var full_name = $('#fname').val();
    var email_id = $('#email').val();
    var mobile = $('#mobile').val();
    var dob = $('#txtdob').val();
    var gender = $('#gender').val();
    var residency_location = $('#residency_location').val();
    var loan_amount = $('#loanamount').val();
    var monthly_income = $('#txtmonthlyincome').val();
    var occupation = $('#occupation').val();
    var resident_type = $('#residency_type').val();
    var past_loan = $('#defaultpastloan').val();
    var copany_name = $('#company_name').val();
    var salary_received = $('#salary_recived').val();
    var since_bussiness = $('#inbusinesssince').val();
    var it_return = $('#itreturnfile').val();
    var turnover = $('#annualturnover').val();
    
    var emi = $('#exitingEMI').val();
   // alert(since_bussiness);
    $("#popupdiv").show();
    
    $.post('sms/personalloansendsms.php',{full_name:full_name,email_id:email_id,mobile:mobile,dob:dob,gender:gender,residency_location:residency_location,loan_amount:loan_amount,monthly_income:monthly_income,occupation:occupation,resident_type:resident_type,past_loan:past_loan,copany_name:copany_name,salary_received:salary_received,since_bussiness:since_bussiness,it_return:it_return,turnover:turnover,emi:emi},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
	});	  
}
function getPersonals(){
    var full_name = $('#fname').val();
    var email_id = $('#email').val();
    var mobile = $('#mobile').val();
    var dob = $('#txtdob').val();
    var gender = $('#gender').val();
    var residency_location = $('#residency_location').val();
    var loan_amount = $('#loanamount').val();
    var monthly_income = $('#txtmonthlyincome').val();
    var occupation = $('#occupation').val();
    var resident_type = $('#residency_type').val();
    var past_loan = $('#defaultpastloan').val();
    var copany_name = $('#company_name').val();
    var salary_received = $('#salary_recived').val();
    var since_bussiness = $('#inbusinesssince').val();
    var it_return = $('#itreturnfile').val();
    var turnover = $('#annualturnover').val();
    var emi = $('#exitingEMI').val();    
    var otpnumber = $('#otpnumber').val();
    var cotp = $('#cotp').val();
    
    if(cotp==otpnumber){            
    $.post('control/personal_control.php?mode=i',{full_name:full_name,email_id:email_id,mobile:mobile,dob:dob,gender:gender,residency_location:residency_location,loan_amount:loan_amount,monthly_income:monthly_income,occupation:occupation,resident_type:resident_type,past_loan:past_loan,copany_name:copany_name,salary_received:salary_received,since_bussiness:since_bussiness,it_return:it_return,turnover:turnover,emi:emi},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
        window.location.href="index.php";
	});	   
    }else{
        alert("Please enter valid OTP");
    }
}
/**************************************End Personal Loan**********************************************/
/**************************************Business Loan**********************************************/
function getBusiness(){
    var full_name = $('#fname').val();
    var email_id = $('#email').val();
    var mobile = $('#mobile').val();
    var dob = $('#txtdob').val();
    var gender = $('#gender').val();
    var residency_location = $('#residency_location').val();
    var loan_amount = $('#loanamount').val();
    var monthly_income = $('#txtmonthlyincome').val();
    var occupation = $('#occupation').val();
    var resident_type = $('#residency_type').val();
    var past_loan = $('#defaultpastloan').val();
    var copany_name = $('#company_name').val();
    var salary_received = $('#salary_recived').val();
    var since_bussiness = $('#inbusinesssince').val();
    var it_return = $('#itreturnfile').val();
    var turnover = $('#annualturnover').val();
    var emi = $('#exitingEMI').val();
    if(loan_amount.length<=5){
        alert("loan amount minimum 50,000");
    }else{
        $("#popupdiv").show();
        $.post('sms/businesssendsms.php',{full_name:full_name,email_id:email_id,mobile:mobile,dob:dob,gender:gender,residency_location:residency_location,loan_amount:loan_amount,monthly_income:monthly_income,occupation:occupation,resident_type:resident_type,past_loan:past_loan,copany_name:copany_name,salary_received:salary_received,since_bussiness:since_bussiness,it_return:it_return,turnover:turnover,emi:emi},
        function(markup){
            $('#popup-main-content').html("");
            $('#popup-main-content').html(markup);
        })
    }	   
}
function getBusinesss(){
    var full_name = $('#fname').val();
    var email_id = $('#email').val();
    var mobile = $('#mobile').val();
    var dob = $('#txtdob').val();
    var gender = $('#gender').val();
    var residency_location = $('#residency_location').val();
    var loan_amount = $('#loanamount').val();
    var monthly_income = $('#txtmonthlyincome').val();
    var occupation = $('#occupation').val();
    var resident_type = $('#residency_type').val();
    var past_loan = $('#defaultpastloan').val();
    var copany_name = $('#company_name').val();
    var salary_received = $('#salary_recived').val();
    var since_bussiness = $('#inbusinesssince').val();
    var it_return = $('#itreturnfile').val();
    var turnover = $('#annualturnover').val();
    var emi = $('#exitingEMI').val();
      
    var otpnumber = $('#otpnumber').val();
    var cotp = $('#cotp').val();
    
    if(cotp==otpnumber){            
    $.post('control/business_control.php?mode=i',{full_name:full_name,email_id:email_id,mobile:mobile,dob:dob,gender:gender,residency_location:residency_location,loan_amount:loan_amount,monthly_income:monthly_income,occupation:occupation,resident_type:resident_type,past_loan:past_loan,copany_name:copany_name,salary_received:salary_received,since_bussiness:since_bussiness,it_return:it_return,turnover:turnover,emi:emi},
	function(markup){
		
		$('#popup-main-content').html("");
		$('#popup-main-content').html(markup);
        window.location.href="index.php";
	});	
    }else{
        alert("Please enter valid OTP");
    }
}
/**************************************End Business Loan**********************************************/

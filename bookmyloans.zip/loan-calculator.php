<div id="loan_elig" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">EMI Calculator</h4>
                  </div>
                  <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                              <label for="loan_amount">Tenure (Months)</label>
                              <input type="text" class="form-control border_radius_none" id="loan_amount" placeholder="Enter Loan Amount">
                            </div>
                        </div>  
                        <div class="col-sm-6">
                            <div class="form-group">
                              <label for="roi">Loan Amount </label>
                              <input type="text" class="form-control border_radius_none" id="roi" placeholder="Rate Of Interest">
                            </div>
                        </div>  
                        <div class="col-sm-6">
                            <div class="form-group">
                              <label for="tenure">Annual Interest Rate</label>
                              <input type="text" class="form-control border_radius_none" id="tenure" placeholder="Loan Tenure">
                            </div>
                        </div>   
                        <div class="col-sm-6">
                            <div class="form-group">
                              <label for="tenure">Monthly Salary</label>
                              <input type="text" class="form-control border_radius_none" id="tenure" placeholder="Loan Tenure">
                            </div>
                        </div>   
                        <div class="col-sm-6">
                            <div class="form-group">
                              <label for="tenure">Total Monthly EMI's</label>
                              <input type="text" class="form-control border_radius_none" id="tenure" placeholder="Loan Tenure">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <button type="button" class="btn btn-primary emi_cal col-white" style="margin-top: 9%;">Calculate</button>
                        </div>  
                    </div>  
                      <hr>
                      <table>
                      <tr>
                        <td style="float:right;"><h4 class="font-key">Are you eligible for loan? :  <br><span style="font-size:12px;">(for Required Amount)</span></h4> </td>      
                        <td style="padding-left:30px;"></td>      
                    </tr>
                      <tr>
                        <td style="float:right;"><h4 class="font-key">EMI  : </h4></td>      
                        <td style="padding-left:30px;"><b>?49,919</b></td>      
                    </tr>
                      <tr>
                        <td style="float:right;"><h4 class="font-key">TLoan amount you are eligible for  : </h4></td>      
                        <td style="padding-left:30px;"><b>?69,80,559</b></td>      
                    </tr>
                      </table>
                      
                      
                      
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  </div>
                </div>

            </div>
        </div>
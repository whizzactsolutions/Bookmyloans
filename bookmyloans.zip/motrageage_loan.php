<?php
require_once("includes/init.php");
?>
<html>
    <head>
        <title>Motrageage Loan | Book My Loan</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include('topheader.php');?>
        <style>
           .con2 /*background image css don't move this css*/
            {
                background-image: url(images/header-bg.jpg);
                background-size: cover;
                background-repeat: no-repeat;
                height: auto;
                margin-top: 52.4px;
            }
        @import url(https://fonts.googleapis.com/css?family=Open+Sans);

body {
  font-family: 'Open Sans', sans-serif;
  background-color: #efefef;
}

        </style>
    </head>
    <body>
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- Navigation Code starts here -->
        <?php include('navigation.php');?>
        <!-- Navigation Code ends here -->
        <?php include('loan-calculator.php'); ?>
<!-- ------------------------------------------------------------------------------------------ -->

        <div class="container-fluid" style="margin-top: 3.8%; background-color: #156DD1;">
            <br><br>
            <h2 class="font-key text-center col-white">Apply For Motrageage Loan</h2>
            <br>
            <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" name="fname" id="fname" value="<?php echo (empty($_GET['email_id'])) ? '' : $_GET['email_id']; ?>" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Full Name</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">     
                      <input type="text" id="mobile" name="mobile" value="<?php echo (empty($_GET['mobile'])) ? '' : $_GET['mobile']; ?>" class="input1" required>
                        <span id="mobileValidation" style="color:#ee5253;font-weight: bold;"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Mobile Number</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="email"  id="email" name="email" value="<?php echo (empty($_GET['email_id'])) ? '' : $_GET['email_id']; ?>" class="input1" required>
                        <span id="emailValidation" style="color:#ee5253;font-weight: bold;"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Email Id</label>
                    </div>
                </div>
            </div>
                
            <div class="row">
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" class="input1" name="loanamount" value="<?php echo (empty($_GET['amount'])) ? '' : $_GET['amount']; ?>" id="loanamount" onkeyup="getloanamount(this.value)" required><span style="color:red;" id="loanamountmsg"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Loan Amount</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">       
                      <input type="text" id="txtmonthlyincome" name="txtmonthlyincome" onkeyup="getmothlyincome(this.value)" class="input1" required>
                        <span id="monthlyincome" style="color:#ee5253;font-weight: bold;"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Monthly Income</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" name="property_value" id="property_value" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Property Value</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="residency_location" class="col-white font-key">Residency Location</label>
                      <select class="form-control border_radius_none" name="residency_location" id="residency_location">
                        <option>Select</option>
                          <?php
                          $location = Locationdetails::find_all();
                          if($location){
                              foreach($location as $alllocation){
                                  echo '<option value="'.$alllocation->location_name.'">'.strtoupper($alllocation->location_name).'</option>';
                              }
                          }
                          
                          ?>
                      </select>
                    </div>
                </div>
                <div class="col-sm-4">
                <div class="form-group">
                      <label for="occupation" class="col-white font-key">Occupation</label>
                      <select name="occupation" id="occupation" onchange="getoccupation(this.value)"  class="form-control border_radius_none" >
                        <option value="">Select</option>
                        <option value="Salaried">Salaried</option>
                        <option value="Self Employed (Business)">Self Employed (Business)</option>
                        <option value="Self Employed (Professional)">Self Employed (Professional)</option>
                        <option value="Retired">Retired</option>
                        <option value="House Wife">House Wife</option>
                      </select>
                    </div>

                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input  type="text" onfocus="(this.type='date')" placeholder="Date of Birth" name="txtdob" id="txtdob" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Date of Birth</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <form>
                    <label class="f16 font-key col-white">Gender</label><br>
                    <label class="radio-inline col-lb"><input type="radio" id="gender" value="Male" name="optradio">Male</label>
                    <label class="radio-inline col-lb"><input type="radio" id="gender"  value="Female" name="optradio">Female</label>
                    </form>
                </div>
            </div><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="checkbox text-center">
                      <label class="col-white font-key f15"><input type="checkbox" value="" checked> I authorize the website and its partners to call or SMS me in connection with my application & I agree to the Privacy Policy and Terms of Use.</label>
                    </div>
                </div>
            </div>
            <center>
                <button type="button" class="btn btn-primary loan-elig col-white" onclick="getmotrageage()">Submit</button>
            </center>
            </div>
            <br>
            <div id="popupdiv" class="popupdiv">
                <div class="popupdiv-content">	
                    <center>
                        <div id="popup-main-content">
                        </div>
                    </center>
                </div>
            </div>
            <div class="container">
                <h3 class="text-center col-white">FAQ For Motrageage Loan</h3><br>
                <dl class="accordion">
                    <dt>Why take a Loan Against property from our company?</dt>
                    <dd> 
                        <p>We accept all- residential, commercial and plot for loans.<br>
					We also offer easy loan repayments with longer repayment tenure and Competitive interest rates.<br>
					We also offer customized loan options for self employed individuals.</p>
                    </dd>

                    <dt>How will you determine my eligibility for a LAP and the loan amount?</dt>
                    <dd>
                        <p>We consider the factors such as age, past borrowing track record, current income, valuation of property, stability of employment/ business, and Existing obligations, if any, to determine eligibility and loan amount.</p>
                    </dd>

                    <dt>What sort of properties can be considered as collaterals?</dt>
                    <dd>
                        <p>The below given properties can be considered as collaterals:</p>
                        <ul>
                           <li>Commercial properties such as offices, shops etc.</li>
					       <li>Self-occupied residential properties</li>
					       <li>Alternate properties such as Residential Plots, Hospitals, Schools, Hotels and Industrial properties.</li>
                        </ul>
                    </dd>
                    
                    <dt>Can there be a co-applicant for LAP? If yes, who can be co-applicant?</dt>
                    <dd>
                        <p>You can include your spouse as a co-applicant. And, if the property is co-owned, then it is mandatory for all co-owners to be co-applicants.</p>
                    </dd>
                    
                    <dt>What is the tenure of the loan?</dt>
                    <dd>
                        <p>LAP has a maximum tenure of 15 years, provided it does not exceed your retirement age. However, this condition can differ from case to case.</p>
                    </dd>
                    
                    <dt>What are the processing fees for such a loan?</dt>
                    <dd>
                        <p>Processing fee for LAP differs from bank to bank and is usually around 1%.</p>
                    </dd>
                    
                    <dt>How do I repay the loan?</dt>
                    <dd>
                        <p>Repayment through Equated Monthly Installments (EMIs) starts from the month following the month in which you take total  disbursement. You repay the loan in EMIs that comprises principal amount and interest.</p>
                    </dd>
                    
                    <dt>What are the various options for making my EMI payments?</dt>
                    <dd>
                        <p>You may repay your LAP in  two ways-Electronic Clearing Service (ECS) & Post-Dated Cheques (PDCs).</p>
                    </dd>
                    
                    <dt>Already have a Loan Against Property?</dt>
                    <dd>
                        <p>You may contact our Representative for any queries related to your Loan Against Property.</p>
                    </dd>
                    
                    <dt>How soon after the foreclosure will I get back my original property documents?</dt>
                    <dd>
                        <p>Once your loan account is closed, you may collect your property documents after couple of weeks  from our branch.</p>
                    </dd>
                    
                </dl>
            </div>
            
            
        <br>
        </div>
        <!-- footer starts here -->
           <?php include('footer.php');?>
        
        <script src="js/whizz.js"></script>
        <script>
          (function( $ ) {
	$.fn.SimpleAccordion = function () {
		// Cache element
		var accordion = $(this);
		// Fade in on load
		accordion.hide().fadeIn();
		// Open active panel
		accordion.find(".active").show();
		// Listen to onClick
		accordion.find("dt").on("click", function (){
			// Cache current
			var current = $(this).next("dd");
			// Check if not active
			if (current.is(":hidden")) {
				// Open curren panel
				current.slideDown().siblings("dd").slideUp();
			}
		});
	};
})( jQuery );

$(".accordion").SimpleAccordion();
        </script>
    </body>
</html>
<nav class="navbar navbar-default navbar-fixed-top nav-col">
            <div class="container">
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>                        
                  </button>
                  <a class="navbar-brand" href="index.php"><strong style="color:#660000;font-size:25px;">BOOK</strong><strong>my</strong><strong style="color:#000033;font-size:25px;">LOANS</strong></a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                  <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown li_hover">
                      <a class="dropdown-toggle" data-toggle="dropdown" href="#loan">LOAN&nbsp;<span class="caret"></span></a>
                      <ul class="dropdown-menu">
                        <li><a href="home_loan.php" class="fon-bann">HOME LOAN</a></li>
                        <li><a href="balance_transfer.php" class="fon-bann">BALANCE TRANSFER</a></li>
                        <li><a href="motrageage_loan.php">MORTGAGES LOAN</a></li>
                        <li><a href="personal_loan.php">PERSONAL LOAN</a></li>
                        <li><a href="business_loan.php">BUSINESS LOAN</a></li>
                      </ul>
                    </li>
                    <li class="nav-seperator li_hover"><a href="index.php#know_about">ABOUT</a></li>
                    <li class="nav-seperator li_hover"><a href="index.php#contact">CONTACT</a></li>&nbsp;&nbsp;
                    <li class="li_hover"><a href="#">UPLOAD PROPERTY</a></li>&nbsp;&nbsp;
                    <button type="button" class="btn btn-primary loan-elig col-white" data-toggle="modal" data-target="#loan_elig">Loan Eligibility</button>
                  </ul>
                </div>
            </div>
        </nav>
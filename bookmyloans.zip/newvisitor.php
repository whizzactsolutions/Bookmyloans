<?php
require_once('includes/init.php');
$visitor=new Visitor();
$vnc=Visitor::find_next_code();
if($vnc)
{
	foreach($vnc as $nextcode)
	{
		$visitor->visitor_code=$nextcode->visitor_code+1;
	}
}
else
{
	$visitor->visitor_code="1200";
}

$visitor->visitor_ip=$_SERVER["REMOTE_ADDR"];

date_default_timezone_set('Asia/Kolkata');
$date = new DateTime(Date("d-m-Y H:i:s"));
$date1= date("d-m-Y");
$date->setTimezone(new DateTimeZone('Asia/Kolkata'));
$visitor->visit_daytime=$date->format("d-m-Y H:i:s A");
$visitor->visit_date=$date1;

$vip=Visitor::find_by_ipdate($_SERVER["REMOTE_ADDR"],$date1);
if(!$vip)
{
$visitor->save();
}
?>
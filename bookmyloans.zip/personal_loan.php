<?php
require_once("includes/init.php");
$posted = array();
if(!empty($_POST)) {
    //print_r($_POST);
  foreach($_POST as $key => $value) {    
    $posted[$key] = $value; 
	
  }
}

?>
<html>
    <head>
        <title>Personal Loan | Book My Loan</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include('topheader.php');?>
        <style>
           .con2 /*background image css don't move this css*/
            {
                background-image: url(images/header-bg.jpg);
                background-size: cover;
                background-repeat: no-repeat;
                height: auto;
                margin-top: 52.4px;
            }
        @import url(https://fonts.googleapis.com/css?family=Open+Sans);

body {
  font-family: 'Open Sans', sans-serif;
  background-color: #efefef;
}

        </style>
    </head>
    <body>
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- Navigation Code starts here -->
        <?php include('navigation.php');?>
        <!-- Navigation Code ends here -->
       <?php include('loan-calculator.php'); ?>
<!-- ------------------------------------------------------------------------------------------ -->

        <div class="container-fluid" style="margin-top: 3.8%; background-color: #156DD1;">
            <br><br>
            <h2 class="font-key text-center col-white">Apply For Personal Loan</h2>
            <br>
            <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" name="fname" id="fname" value="<?php echo (empty($_GET['email_id'])) ? '' : $_GET['email_id']; ?>" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Full Name</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" id="mobile" name="mobile" value="<?php echo (empty($_GET['mobile'])) ? '' : $_GET['mobile']; ?>" class="input1" required>
                        <span id="mobileValidation" style="color:#ee5253;font-weight: bold;"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Mobile Number</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="email" id="email" name="email" value="<?php echo (empty($_GET['email_id'])) ? '' : $_GET['email_id']; ?>" class="input1" required>
                        <span id="emailValidation" style="color:#ee5253;font-weight: bold;"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Email Id</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="sel1" class="col-white font-key">Occupation</label>
                      <select name="occupation" id="occupation" onchange="getoccupation(this.value)" class="form-control border_radius_none" id="sel1">
                        <option value="">Select</option>
                        <option value="Salaried">Salaried</option>
                        <option value="Self Employed (Business)">Self Employed (Business)</option>
                        <option value="Self Employed (Professional)">Self Employed (Professional)</option>
                      </select>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="residency_type" class="col-white font-key">Residence Type</label>
                      <select class="form-control border_radius_none" name="residency_type" id="residency_type">
                        <option value="">Select</option>
                        <option value="Self/Spouse Owned">Self/Spouse Owned</option>
                        <option value="Family Owned">Family Owned</option>
                        <option value="Rented Accomodation">Rented Accomodation</option>
                      </select>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="defaultpastloan" class="col-white font-key">Default In Past Loan</label>
                      <select class="form-control border_radius_none" name="defaultpastloan" id="defaultpastloan">
                        <option>Select</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                      </select>
                    </div>
                </div>

            </div>
                <div id="onchangedata" style="display:none;"><div class="row">
                    <div class="col-sm-4"><div class="group1"><input type="text" name="company_name" id="company_name" value="<?php echo (empty($posted['company_name'])) ? '' : $posted['company_name'] ?>"  class="input1" required><span class="highlight1"></span><span class="bar1"></span><label class="label1">Company Name</label></div></div>                     <div class="col-sm-4">
                    <div class="form-group">
                      <label for="salary_received" class="col-white font-key">Salary Received As</label>
                      <select class="form-control border_radius_none" name="salary_received" id="salary_received">
                        <option value="">Select</option>
                          <optgroup  label="Electronic Tranfer">
                        <option value="HDFC Bank">HDFC Bank</option>
                        <option value="ICIC Bank">ICIC Bank</option>
                        <option value="Axis Bank">Axis Bank</option>
                        <option value="Kotak Bank">Kotak Bank</option>
                        <option value="HSBC Bank">HSBC Bank</option>
                        <option value="Standard Chartered Bank">Standard Chartered Bank</option>
                        <option value="Citi Bank">Citi Bank</option>
                        <option value="Other Bank">Other Bank</option>
                          </optgroup>
                          <option value="Cheque">Cheque</option>
                          <option value="Cash">Cash</option>
                      </select>
                    </div>
                </div>
                </div></div>
                
                <div id="onchangedata1" style="display:none;">
                <div class="row"><div class="col-sm-4"> <div class="form-group"><label for="inbusinesssince" class="col-white font-key">In Business Since</label><select class="form-control border_radius_none" id="inbusinesssince"  value="<?php echo (empty($posted['inbusinesssince'])) ? '' : $posted['inbusinesssince'] ?>"> <option value="NA">Select</option><option value="Less than 2 Years">Less than 2 years</option><option value="2 to 5 years">2 to 5 years</option><option value="5 to 10 years">5 to 10 years</option></select></div></div>         <div class="col-sm-4"> <div class="form-group"><label for="itreturnfile" class="col-white font-key">IT Returns Filed</label><select class="form-control border_radius_none" value="<?php echo (empty($posted['itreturnfile'])) ? '' : $posted['itreturnfile'] ?>" id="itreturnfile"> <option value="NA">Select</option><option value="Less than 2 Years">Less than 2 years</option><option value="2 or more years">2 or more years</option></select></div></div>           <div class="col-sm-4"><div class="group1"><input type="text" name="annualturnover" value="<?php echo (empty($posted['annualturnover'])) ? '' : $posted['salary_recived'] ?>"  id="annualturnover" class="input1" required><span class="highlight1"></span><span class="bar1"></span><label class="label1">Annual Turnover</label></div></div></div>
                </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" class="input1"  name="loanamount" value="<?php echo (empty($_GET['amount'])) ? '' : $_GET['amount']; ?>" id="loanamount" minlenth="5" required><span style="color:red;" id="loanamountmsg"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Loan Amount</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text"  id="txtmonthlyincome" name="txtmonthlyincome" onkeyup="getmothlyincome(this.value)" class="input1" required>
                        <span id="monthlyincome" style="color:#ee5253;font-weight: bold;"></span>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Montly Income</label>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input type="text" name="exitingEMI" id="exitingEMI" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Existing EMI (If any)</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                      <label for="residency_location" class="col-white font-key">Residency Location</label>
                      <select class="form-control border_radius_none" name="residency_location" id="residency_location">
                        <option>Select</option>
                          <?php
                          $location = Locationdetails::find_all();
                          if($location){
                              foreach($location as $alllocation){
                                  echo '<option value="'.$alllocation->location_name.'">'.strtoupper($alllocation->location_name).'</option>';
                              }
                          }
                          
                          ?>
                      </select>
                    </div>
                </div>
                <div class="col-sm-4">
                    <form>
                    <label class="f16 font-key col-white">Gender</label><br>
                    <label class="radio-inline col-lb"><input type="radio" id="gender" value="Male" name="optradio">Male</label>
                    <label class="radio-inline col-lb"><input type="radio" id="gender"  value="Female" name="optradio">Female</label>
                    </form>
                </div>
                <div class="col-sm-4">
                    <div class="group1">      
                      <input  type="text" onfocus="(this.type='date')" placeholder="Date of Birth" name="txtdob" id="txtdob" class="input1" required>
                      <span class="highlight1"></span>
                      <span class="bar1"></span>
                      <label class="label1">Date of Birth</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="checkbox text-center">
                      <label class="col-white font-key f15"><input type="checkbox" value="" checked> I authorize the website and its partners to call or SMS me in connection with my application & I agree to the Privacy Policy and Terms of Use.</label>
                    </div>
                </div>
            </div>
            <center>
                <button type="button" class="btn btn-primary loan-elig col-white" onclick="getPersonal()">Submit</button>
            </center>
            </div>
            <br>
            <div id="popupdiv" class="popupdiv">
                <div class="popupdiv-content">	
                    <center>
                        <div id="popup-main-content">
                        </div>
                    </center>
                </div>
            </div>
            <div class="container">
                <h3 class="text-center col-white">FAQ For Personal Loan</h3><br>
                <dl class="accordion">
                    <dt>What are the pros &amp; cons of personal loan?</dt>
                    <dd> 
                        <p>
                            Personal Loan helps you sort out your money issues but they do have pros and cons.<br>
                            <b>Pros:</b><br>
                            No collateral security,  Quick Approval, and Less Documentation are some of the pros of personal loan.<br>
                            <b>Cons:</b><br>
                            Prepayment penalty,  High Interest Rates and Strict Qualification Criteria are some of the cons of personal loan.
                        </p>
                    </dd>

                    <dt>What are the loan tenure options?</dt>
                    <dd>
                        <p>A personal loan can be repaid over a tenure of 12 to 60 months.</p>
                    </dd>

                    <dt>How much time do you take to approve a personal loan?</dt>
                    <dd>
                        <p>A personal loan are approved within 72 hours after the completion of your documentation part. Time limit may differ from case to case.</p>
                    </dd>
                    
                    <dt>How can I get better rate of interest for my personal loan?</dt>
                    <dd>
                        <p>A good track record for repayment of loans will help you grab attractive interest rate deals for the borrowed personal loan amount.</p>
                    </dd>
                    
                    <dt>I am planning to buy a car for commercial purpose. Should I take Personal Loan or Car Loan?</dt>
                    <dd>
                        <p>If you are planning to buy a car for commercial purpose, you may apply for Commercial Vehicle loan or Personal Loan. When it comes to commercial vehicle loans, they are comparatively cheaper than personal loan. But, you have to meet some  specific eligibility criteria. If you fail to meet the eligibility criteria of commercial vehicle loan, you can opt for a personal loan.</p>
                    </dd>
                    
                    <dt>Do I have to provide any collateral or guarantors?</dt>
                    <dd>
                        <p>No, guarantor or collaterals are required for personal loans.</p>
                    </dd>
                    
                    <dt>How do I approach you for  a personal loan?</dt>
                    <dd>
                        <p>You may apply online or call our round the clock customer care center, you also have an option to drop us an email or walk into our office.</p>
                    </dd>
                    
                    <dt>Do you offer top up on existing Personal Loans/ balance transfer facility?</dt>
                    <dd>
                        <p>Yes, we do offer balance transfer facility/ top up on existing Personal Loans. For more info on this, please get in touch with us.</p>
                    </dd>
                    
                    <dt>Is there a prepayment penalty on personal loan?</dt>
                    <dd>
                        <p>Yes. We do charge prepayment penalty  that varies from 1% to 3% on the outstanding principal amount of a personal loan, depending upon the case.</p>
                    </dd>
                    
                    <dt>How to prepay my personal loan, if I am unable to visit your center?</dt>
                    <dd>
                        <p>You may send your representative with an authority letter duly signed by you (loan applicant), for payment. Third party or Co-applicant visiting the center for prepaying the loan must carry the below depicted documents:</p>
                        <ul>
                            <li>Authorization letter from main applicant.</li>
                            <li>Main applicant Identification proof -Driving License or Passport/ PAN Card/ Voters card.</li>
                        </ul>
                    </dd>
                    
                    <dt>What are the other costs that come with home loans?</dt>
                    <dd>
                        <p>What is the procedure to prepay my personal loan?</p>
                        <ul>
                            <li>Request Letter signed by you (loan applicant).</li>
                            <li>PAN Card (if the mode of payment is cash and the cash amount > Rs.50,000)</li>
                            <li>Payment can be made through cash/ cheque/ demand draft.</li>
                        </ul>
                    </dd>
                    
                    <dt>How can I repay the Personal loan Amount?</dt>
                    <dd>
                        <p>You can repay the personal loan amount in EMIs- Equated Monthly Installments via post-dated cheques (PDC) favoring The Company Name. You may also pay it by Electronic Clearing Services (ECS).</p>
                    </dd>
                </dl>
            </div>
            
            
        <br>
        </div>
        <!-- footer starts here -->
            <?php include('footer.php');?>
        
        <script src="js/whizz.js"></script>
        <script>
          (function( $ ) {
	$.fn.SimpleAccordion = function () {
		// Cache element
		var accordion = $(this);
		// Fade in on load
		accordion.hide().fadeIn();
		// Open active panel
		accordion.find(".active").show();
		// Listen to onClick
		accordion.find("dt").on("click", function (){
			// Cache current
			var current = $(this).next("dd");
			// Check if not active
			if (current.is(":hidden")) {
				// Open curren panel
				current.slideDown().siblings("dd").slideUp();
			}
		});
	};
})( jQuery );

$(".accordion").SimpleAccordion();
            
/*****************************************occupation ***********************************/
            function getoccupation(occupation){
                if(occupation=='Salaried'){
                    $('#onchangedata1').hide();
                    $('#onchangedata').show();
                }
                if(occupation=='Self Employed (Business)'){
                    $('#onchangedata1').show();
                    $('#onchangedata').hide();
                }
                if(occupation=='Self Employed (Professional)'){
                    $('#onchangedata1').show();
                    $('#onchangedata').hide();
                }
                if(occupation==''){
                    $('#onchangedata1').hide();
                    $('#onchangedata').hide();
                }
               
            }
        </script>
    </body>
</html>
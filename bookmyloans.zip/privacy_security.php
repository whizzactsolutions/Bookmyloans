<html>
    <head>
        <title>Book My Loan</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include('topheader.php');?>
        <style>
           .con2 /*background image css don't move this css*/
            {
                background-image: url(images/header-bg.jpg);
                background-size: cover;
                background-repeat: no-repeat;
                height: auto;
                margin-top: 52.4px;
            }
            .font-para
            {
                font-family: 'PT Sans', sans-serif;
                font-size: 18px;
            }
        </style>
    </head>
    <body>
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- Navigation Code starts here -->
        <?php include('navigation.php');?>
        <?php include('loan-calculator.php'); ?>
        <!-- Navigation Code ends here -->
<!-- ------------------------------------------------------------------------------------------ -->
       <div class="container" style="margin-top: 3.8%;">
           <br>
           <h3 class="text-center font-key"><b>PRIVACY AND SECURITY POLICY</b></h3>
           <hr>
           <p class="font-para">
               Its customers (hereinafter referred to as "customer / you / your") in respect to security, confidentiality and privacy of their Personal Information that resides with the Bookmyloans.co.in. Our top priority is to prevent any misuse of the customer's personal information and keep the same safe and secure. Bookmyloans.co.in shall not be held liable for disclosure of the confidential personal information with respect to this privacy commitment/ agreement/ Terms of Use of Website, if any, with the customers as we have taken reasonable measures in sync with the best industry practice in order to protect the confidentiality of the customer information. We at Bookmyloans.co.in are totally committed to protect the privacy of our customers.
           </p>
           <p class="font-para">
           This Privacy &amp; Security Policy (hereinafter referred to as "Policy") refers to the details of the process we perform while protecting your Personal Information provided to our websites such as www.Bookmyloans.co.in (hereinafter referred to as "Website") and it will also explain how we collect information in connection with our service offered via this Website (hereinafter called as "Service").
           </p><br>
           <h4 class="font-key f20"><b>Personal Information</b></h4>
           <p class="font-para">
            Personal Information refers to any sensitive info ("SI") / details/ documents that is related to a natural person directly or indirectly, in combination with other information available or likely to be available with the Bookmyloans.co.in. And, this information is capable of identifying such person.
           </p><br>
           <h4 class="font-key f20"><b>Applicability</b></h4>
           <p class="font-para">
                The said Policy is applicable to the Personal Information, including but not limited to details related to your name, marital status, nationality, family, email address, gender, date of birth, contact number/mobile number, city of residence, user IDs, passwords, state of residence, signature image, recent photograph, e-KYC through UIDAI, other Know Your Customer (KYC) documents like income proof, address proof, PAN, identity proof, or other officially valid details or documents (OVDs) accepted for financial transaction completion which are either uploaded or shared by you, as and when you avail the products &amp; services by filling up online application forms and questionnaires via usage of Bookmyloans.co.in Website. This policy is applicable to all online customers, former and current visitors to the website. And, by using or visiting our website, you agree to the said policy.
           </p>
           <p class="font-para">
               <b>Bookmyloans.co.in</b> reserves the right at any time, at its sole discretion, to modify or change the Policy without prior notice, and your continued use of our Website signifies that you accept our modified Policy. In any case, we make some changes to the Policy; we will inform you by notice on this Website prior to the change becoming effective or we will inform you via email (sent to the e-mail address specified in your account). Hence, it is advisable to return to this page once in a while to review the updated version of the Policy.
           </p><br>
           <h4 class="font-key f20"><b>Express Consent</b></h4>
           <p class="font-para">
               While providing the details/documents over the Website, including but not limited to Personal Information as mentioned hereinabove, expressly consent to Bookmyloans.co.in to contact you, to allow us to make follow up calls with regard to the products and services provided through our Website, for offering promotional offers running on Website and for giving knowledge about the product.
           </p>
           <p class="font-para">
                The access of our Website may ask you to offer consent for uploading your Personal Information ("SI- Sensitive information") (including but not limited to user ids and passwords), as it may be required to process your application through the Website. SI uploaded shall be required for enabling fast and hassle free processing of applications for financial products and services availed by you or opted by you.
           </p>
           <p class="font-para">
                Moreover, with regard to your usage of the Website, you expressly waive the Do Not Disturb (DND)/ Do Not Call (DNC) registrations on your phone/mobile numbers for contacting you for this purpose. Hence, there is no DNC / DND check required for the number you have left or you have shared on our Website. Sending email alerts, sending SMSs and/ or telephonic calls may include such modes of contact.
           </p>
           <p class="font-para">
                You expressly authorize Bookmyloans.co.in and we reserve the right to disclose or share your Personal Information (SI) when Bookmyloans.co.in determines, in its sole discretion that the disclosure of such information is appropriate and is required under the current law.
           </p><br>
           
           <h4 class="font-key f20"><b>Purpose and Usage</b></h4>
           <p class="font-para">
               When it comes to purpose and usage of your personal information, Bookmyloans.co.in will not sell or rent your Personal Information to third party or any one, for any reason, at any point in time. However, we may share your Personal Information (Sensitive Information) with our business partners and associates, wherein they will be able to assist you for underwriting and approval of your approving investment in Mutual Fund, loan, credit card, and loan or any other financial product or services transaction. In order to enhance your personal online experience on its Website, Bookmyloans.co.in uses the collected information and aptly notifies you to manage its business. Moreover, it enables Bookmyloans.co.in to: improve the Service and analyze usage of its Website; send you any offer alerts, communications and admin notices relevant to your usage of the Service; allow you to apply for financial products &amp; services that you have chosen to apply for; Detecting and protecting against fraud, error or any other criminal activity, carry market research program, troubleshooting issues, project planning; bind third-party contractors that offer services to Bookmyloans.co.in and they are bound by same privacy restrictions; Comply with all applicable laws &amp; regulations; enforce Bookmyloans.co.in Terms of Use.
           </p>
           <p class="font-para">
                In case, you use the Service offered by our associates or partners either through our Website or on being redirected from a co-branded URL otherwise referred to as a white-label site, your details such as your name, mobile number, e-mail address, employment type, date of birth, residency status, PAN, income details/proofs, details of loan / credit card/ Mutual Fund applied for and loan, credit card and Mutual Fund status or any other financial product status as may be provided to that concerned partner while submitting your application and as and when the application status is updated. Bookmyloans.co.in has tied up with these business partners and you may not opt-out of sharing your information with these partners if you have applied directly via Website or via a co-branded URL depending upon the case.
           </p>
           <p class="font-para">
                For availing the Service such as applying for a credit card, loan, Mutual Fund or any other financial product or service you are required to provide/upload on the Website various details such as a your name, marital status, parentage, email address, location, nationality, mobile number, employment &amp; income details/proofs, PAN, recent photograph, signature image, other Know Your Customer (KYC) documents like address proof, identity proof and personally identifying information about a potential co-loan applicant (if you select this option), password and to participate on Bookmyloans.co.in's forum boards, a username (collectively the "Registration Information").
           </p>
           <p class="font-para">
               At any time, you are free to opt out of location based services by editing the setting of your browser. In order to provide pay slip electronically or your bank statement along with your loan application, you also must provide your third-party "Account Credentials" to allow Bookmyloans.co.in to recover your account data at those other financial institutions for your use. We use your Account Credentials only once to retrieve your bank statements/pay slips and we do not store the same in our system. However, Bookmyloans.co.in shall not be liable to you against any claims or liability which may arise out of such transactions being carried on your own accord.
           </p>
           <p class="font-para">
                We may also use third party service providers to provide the Service to you, such as sending e-mail messages on Bookmyloans.co.in's behalf or operating a particular feature Of the Service.
           </p>
           <p class="font-para">
                We make sure that these third parties maintain the privacy of the information provide to them. Our contracts with these third parties outline the appropriate use and cautious handling of your information. These contracts also prohibit them from using any of your Personal Information apart from the purposes related to the service or product they're offering.
           </p><br>
           
           <h4 class="font-key f20"><b>Disclosure / Sharing</b></h4>
           <p class="font-para">
                Bookmyloans.co.in does not disclose your personal information or sensitive personal data except as directed by law or as per mandate received from the applicant/customer. Upon your written request Bookmyloans.co.in will provide you with information in case we hold any of your personal information. No personally identifiable data or specific information about customer accounts is shared with non-affiliated third parties unless any of the following conditions is met: - To help complete a transaction made by you - To perform support services through a third-party service provider provided it is in line with our Privacy Policy and your prior consent to do so is obtained - You have specifically authorized it - The disclosure is necessary for compliance as required by law, such as to comply with a subpoena, or similar legal process - The information is shared with any third party or Government agencies by an order under the law. - In case disclosure is necessary to protect the safety of others, to protect your safety, protect our rights, investigate fraud, or respond to a government request.
        </p><br>
           
           <h4 class="font-key f20"><b>Intimation by customers with regard to change in registration information</b></h4>
           <p class="font-para">
                If your Registration Information provided to us when you had applied for a product on our Website changes, you may update it as and when you apply for a new product through our Website. You may contact us at support[at]Bookmyloans.co.in.com, to update your Personal Information, in this way you may ensure that the same is correct while your application is in process. You will not be able to update your information you have submitted in an application after a decision has already been made on it; but you may create a new application with your updated information and submit the same.
           </p>
           <p class="font-para">
                <b>Note : </b>We will keep your information with us as long as your account is needed to provide you our services. If you want us to close your account or if you wish that we no longer use your information to offer you services, contact us at support[at]Bookmyloans.co.in.com. We will reply to your request within a stipulated timeframe. However, we may use your information to comply with our legal obligations, to enforce our agreements and resolve disputes.
           </p><br>
           
           <h4 class="font-key f20"><b>Email &amp; SMS communications from us and our business partners</b></h4>
           <p class="font-para">
                Our registered customers receive periodic email/SMS alerts and emailers. Users may subscribe to our email newsletters and on timely basis we may transmit emails promoting ouror third-party products. Bookmyloans.co.in's Website subscribers may opt-out of receiving our promotional emails and may terminate their newsletter subscriptions by going through the said instructions in the emails. Opting out in this manner will not end transmission of services such as email/SMS alerts. These services are also offered by our associates and partners.
           </p><br>
           
           <h4 class="font-key f20"><b>Log Files</b></h4>
           <p class="font-para">
                This information may include internet protocol (IP) addresses, internet service provider (ISP), referring/exit pages, browser type, click stream data, operating system, and date/time stamp. To improve our services, marketing, and analytics, enhance your online experience, we may use this collected log information about you.
           </p><br>
           
           <h4 class="font-key f20"><b>Tracking Technologies</b></h4>
           <p class="font-para">
                Bookmyloans.co.in and its partners use cookies/ similar technologies to administer the website, analyze trends, to gather demographic information about our user base and to track users movements around the website. At an individual browser level, you can control the use of cookies, but it may limit your use of some functions or service on our website, in case you choose to disable cookies.
           </p><br> 
           
           <h4 class="font-key f20"><b>Behavioral Targeting / Re-Targeting</b></h4>
           <p class="font-para">
                We partner with a third-party service provider to manage our advertising on other sites or to display advertising on our Website. Our third-party partner may gather information about your activities through cookies on our Website and other Sites in order to provide you advertising based upon your browsing activities and interests. If you wish to not have this information used for the purpose of serving you interest-based ads, you may opt-out by clicking here. Please note this does not opt you out of being served ads. You will continue to receive generic ads.
           </p>
           <p class="font-para">
                Third parties will not be given your Personal Information unless you direct Bookmyloans.co.in to do so: Credit cards, loans, Mutual Fund and other financial products are the products and services offered by third parties on our Website. These third parties are banks, lenders, credit card issuers and mutual funds.
           </p>
           <p class="font-para">
                Disclose your information to the providers, if you opt for these separate products or services. Their use of your personal information is governed by their privacy policies. So, you should evaluate the pros and cons of these external services providers before deciding to use their services. Bookmyloans.co.in is not responsible for their privacy practices.
           </p><br>
           
           <h4 class="font-key f20"><b>Testimonials, Blogs and other forums on Bookmyloans.co.in Website</b></h4>
           <p class="font-para">
                <b>Bookmyloans.co.in</b> may post your testimonial along with your name, with your consent. If you do not want your testimonial to be there on website, please contact Bookmyloans.co.in at support@Bookmyloans.co.in.
           </p>
           <p class="font-para">
                Our website includes Widgets that are interactive mini-programs run on our Website to offer specific services from third party such as displaying the opinions, news, music, etc. Cookies may also be set by the Widget in order to function properly. Your email address and other Personal Information may be collected through the Widget. Please note that information captured by this Widget is not governed by the Bookmyloans.co.in as it is governed by the privacy policy of the company that created it.
           </p><br>
           
           <h4 class="font-key f20"><b>Additional Policy Information</b></h4>
           <p class="font-para">
               Our website includes Widgets that are interactive mini-programs run on our Website to offer specific services from third party such as displaying the opinions, news, music, etc. Cookies may also be set by the Widget in order to function properly. Your email address and other Personal Information may be collected through the Widget. Please note that information captured by this Widget is not governed by the Bookmyloans.co.in as it is governed by the privacy policy of the company that created it.
           </p>
           <p class="font-para">
                You can easily log in to our Website using sign-in services such as an Open ID provider or Facebook Connect. While these services will verify your identity, it will also offer you with the information to share certain Personal Information with us like your name, your sign-in information and email address to link between the sites.
           </p>
           <p class="font-para">
                These Social networking media services like Twitter & Facebook offer you choices to post information about your activities on this Website to your profile page to share with others within your network.
           </p>
           <p class="font-para">
                If you use the "Like" button to share something that item will appear on your Facebook profile page. Depending on your Facebook privacy settings, it may also appear on your friends newsfeed. In the future, you may also receive updates in your Facebook newsfeed from this Website. Facebook also collects information about the pages you have visited on this and other sites that have implemented the "Like" button.
           </p>
           <p class="font-para">
               If you use the "Like" button to share something that item will appear on your Facebook profile page. Depending on your Facebook privacy settings, it may also appear on your friends newsfeed. In the future, you may also receive updates in your Facebook newsfeed from this Website. Facebook also collects information about the pages you have visited on this and other sites that have implemented the "Like" button.
           </p><br>
           
           <h4 class="font-key f20"><b>We keep your data secure:</b></h4>
           <p class="font-para">
                We follow generally accepted standards to keep your Personal Information submitted to us secure, both during transmission and once we obtain it. As we all know that there is no method of electronic storage or method of transmission over the Internet is 100% secure, therefore, we cannot guarantee its absolute security. You can contact us at privacy[at]Bookmyloans.co.in.com, if you have any questions about security on our Website.
           </p>
           <p class="font-para">
                We follow many techniques to maintain the security of your online session and procedures to protect Bookmyloans.co.in online accounts and its systems from unauthorized access. We use a combination of authentication procedures, firewalls, and encryption techniques, etc. When you register for the Service, Bookmyloans.co.in asks for a password from you so that you can have a secure online access. Bookmyloans.co.in transmits information such as Account Credentials or your Registration Information for Website securely.
           </p>
           <p class="font-para">
                We follow many techniques to maintain the security of your online session and procedures to protect Bookmyloans.co.in online accounts and its systems from unauthorized access. We use a combination of authentication procedures, firewalls, and encryption techniques, etc. When you register for the Service, Bookmyloans.co.in asks for a password from you so that you can have a secure online access. Bookmyloans.co.in transmits information such as Account Credentials or your Registration Information for Website securely.
           </p>
           <p class="font-para">
                <b>All Personal Information are encrypted and communicated between your computer and our Website securely.</b> In this way, tampering, message forgery and eavesdropping can be prevented and client and server applications can communicate safely. Please note that you are responsible for keeping your login id and password details secure. Kindly do not divulge these personal credentials to any third party. You must contact us immediately at privacy@Bookmyloans.co.in, as soon as you believe that your personal credentials have been made known to others or been stolen. We are not responsible if someone else accesses your account through Registration Information they have obtained from you or through a violation by you of our (Bookmyloans.co.in) Terms of Use or our Privacy and Security Policy.
           </p>
           <p class="font-para">
               If you have any security related concern, please contact us at privacy[at]Bookmyloans.co.in.com. We will take swift action and will address your concerns as soon as possible.
           </p>
           <p class="font-para">
                <b>Contact us with any questions or concerns (Grievance Redressal)</b> If you have grievance or complaint, questions, comments, concerns or feedback in relation to the processing of information or regarding this Privacy and Security Policy or any other privacy or security concern, send an e-mail to privacy@Bookmyloans.co.in.
           </p>
           <br>

           <hr>
       </div>
<!-- ------------------------------------------------------------------------------------------ -->
        <!-- footer starts here -->
           <?php include('footer.php');?>
    </body>
</html>
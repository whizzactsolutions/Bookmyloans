<?php

    $full_name = $_POST['full_name'];
    $email_id = $_POST['email_id'];
    $mobile = $_POST['mobile'];
    $txtdob = $_POST['txtdob'];
    $optradio = $_POST['optradio'];
    $purpose = $_POST['purpose'];
    $occupation = $_POST['occupation'];
    $residency_location = $_POST['residency_location'];
    $loanamount = $_POST['loanamount'];
    $txtmonthlyincome = $_POST['txtmonthlyincome'];
    $coapplicant1 = $_POST['coapplicant1'];
    $coapp_income = $_POST['coapp_income'];
    $propertyradio = $_POST['propertyradio'];
    $propert_location = $_POST['propert_location'];
    $property_value = $_POST['property_value'];
    $property_name = $_POST['property_name'];
    $copany_name = $_POST['copany_name'];    
    $salary_received = $_POST['salary_received'];
    $since_bussiness = $_POST['since_bussiness'];
    $it_return = $_POST['it_return'];
    $turnover = $_POST['turnover'];
    $existingbank = $_POST['existingbank'];

    $rand= rand(000000,999999);
	// Authorisation details.
	$username = "rajesh.salunke@outlook.com";
	$hash = "9d7b37ed31269485ca540c2324641e116b7392df7a7c93a6644ad5a3e4c6b4c1";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = '91'.$mobile; // A single number or a comma-seperated list of numbers
	$message = $rand.' is the One Time Password (OTP) for Balance Transfer from BookMyLoans. valid till '.date('d/m/Y').'.';
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	curl_close($ch);

?>
<input type="hidden" id="full_name" value="<?php echo $full_name;?>">
<input type="hidden" id="email_id" value="<?php echo $email_id;?>">
<input type="hidden" id="mobile" value="<?php echo $mobile;?>">
<input type="hidden" id="txtdob" value="<?php echo $txtdob;?>">
<input type="hidden" id="optradio" value="<?php echo $optradio;?>">
<input type="hidden" id="purpose" value="<?php echo $purpose;?>">
<input type="hidden" id="occupation" value="<?php echo $occupation;?>">
<input type="hidden" id="residency_location" value="<?php echo $residency_location;?>">
<input type="hidden" id="loanamount" value="<?php echo $loanamount;?>">
<input type="hidden" id="txtmonthlyincome" value="<?php echo $txtmonthlyincome;?>">
<input type="hidden" id="coapplicant1 " value="<?php echo $coapplicant1;?>">
<input type="hidden" id="coapp_income" value="<?php echo $coapp_income;?>">
<input type="hidden" id="propertyradio" value="<?php echo $propertyradio;?>">
<input type="hidden" id="propert_location" value="<?php echo $propert_location;?>">
<input type="hidden" id="property_value" value="<?php echo $property_value;?>">
<input type="hidden" id="property_name" value="<?php echo $property_name;?>">
<input type="hidden" id="copany_name" value="<?php echo $copany_name;?>">
<input type="hidden" id="salary_received" value="<?php echo $salary_received;?>">
<input type="hidden" id="since_bussiness" value="<?php echo $since_bussiness;?>">
<input type="hidden" id="it_return" value="<?php echo $it_return;?>">
<input type="hidden" id="turnover" value="<?php echo $turnover;?>">
<input type="hidden" id="existingbank" value="<?php echo $existingbank;?>">
<input type="hidden" id="otpnumber" value="<?php echo $rand;?>">
Enter OTP : <input type="text" name="cotp" id="cotp">
<br><br>
<button onclick="getbalancetransfers()">Submit</button>
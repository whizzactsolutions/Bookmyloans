<?php

    $mobile = $_POST['mobile'];
    $full_name = $_POST['full_name'];
    $email_id = $_POST['email_id'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $residency_location = $_POST['residency_location'];
    $loan_amount = $_POST['loan_amount'];
    $monthly_income = $_POST['monthly_income'];
    $occupation = $_POST['occupation'];
    $property_value = $_POST['property_value'];

    $rand= rand(000000,999999);
	// Authorisation details.
	$username = "rajesh.salunke@outlook.com";
	$hash = "9d7b37ed31269485ca540c2324641e116b7392df7a7c93a6644ad5a3e4c6b4c1";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = '91'.$mobile; // A single number or a comma-seperated list of numbers
	$message = $rand.' is the One Time Password (OTP) for Home Loan from BookMyLoans. valid till '.date('d/m/Y').'.';
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	curl_close($ch);

?>
<input type="hidden" id="full_name" value="<?php echo $full_name;?>">
<input type="hidden" id="email_id" value="<?php echo $email_id;?>">
<input type="hidden" id="mobile" value="<?php echo $mobile;?>">
<input type="hidden" id="dob" value="<?php echo $dob;?>">
<input type="hidden" id="gender" value="<?php echo $gender;?>">
<input type="hidden" id="residency_location" value="<?php echo $residency_location;?>">
<input type="hidden" id="loan_amount" value="<?php echo $loan_amount;?>">
<input type="hidden" id="monthly_income" value="<?php echo $monthly_income;?>">
<input type="hidden" id="occupation" value="<?php echo $occupation;?>">
<input type="hidden" id="property_value" value="<?php echo $property_value;?>">
<input type="hidden" id="otpnumber" value="<?php echo $rand;?>">
Enter OTP : <input type="text" name="cotp" id="cotp">
<br><br>
<button onclick="getmotrageages()">Submit</button>
<button onclick="getmotrageages()">Submit</button>